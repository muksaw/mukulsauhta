from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

BASE_USECOLS = [
    "Station",
    "Ob",
    "value",
    "measure",
    "R_flag",
    "I_flag",
    "Z_flag",
    "B_flag",
    "target",
]

FLAG_COLS = ["R_flag", "I_flag", "Z_flag", "B_flag"]
LAG_STEPS = [1, 5, 15, 30]
ROLL_WINDOWS = [5, 15, 30, 60]


def dedupe_keep_order(items: List[str]) -> List[str]:
    return list(dict.fromkeys(items))


def safe_write(df: pd.DataFrame, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.suffix == ".parquet":
        try:
            df.to_parquet(path, index=False)
            return path
        except Exception:
            fallback = path.with_suffix(".csv")
            df.to_csv(fallback, index=False)
            return fallback
    df.to_csv(path, index=False)
    return path


def load_station_metadata(readme_xlsx: Optional[Path]) -> Optional[pd.DataFrame]:
    if readme_xlsx is None or not readme_xlsx.exists():
        return None
    try:
        station_meta = pd.read_excel(readme_xlsx, sheet_name="station_metadata")
    except Exception:
        return None

    keep = [
        "Station",
        "latitude_degrees_north",
        "longitude_degrees_east",
        "elevation_feet",
        "county",
        "city",
    ]
    keep = [c for c in keep if c in station_meta.columns]
    station_meta = station_meta[keep].copy()
    return station_meta


def optimize_label_dtypes(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    if "Station" in df.columns:
        df["Station"] = df["Station"].astype("category")
    if "measure" in df.columns:
        df["measure"] = df["measure"].astype("category")
    for col in ["value"] + [c for c in FLAG_COLS if c in df.columns]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    if "target" in df.columns:
        if pd.api.types.is_bool_dtype(df["target"]):
            df["target"] = df["target"].astype("int8")
        else:
            df["target"] = (
                df["target"].astype(str).str.lower().map({"true": 1, "false": 0})
                .fillna(pd.to_numeric(df["target"], errors="coerce"))
                .astype("int8")
            )
    return df


def add_base_features(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["Ob"] = pd.to_datetime(out["Ob"], errors="coerce")

    out["hour"] = out["Ob"].dt.hour.astype("int16")
    out["dayofweek"] = out["Ob"].dt.dayofweek.astype("int16")
    out["month"] = out["Ob"].dt.month.astype("int16")
    out["dayofyear"] = out["Ob"].dt.dayofyear.astype("int16")
    out["is_weekend"] = out["dayofweek"].isin([5, 6]).astype("int8")

    out["hour_sin"] = np.sin(2 * np.pi * out["hour"] / 24)
    out["hour_cos"] = np.cos(2 * np.pi * out["hour"] / 24)
    out["doy_sin"] = np.sin(2 * np.pi * out["dayofyear"] / 365.25)
    out["doy_cos"] = np.cos(2 * np.pi * out["dayofyear"] / 365.25)

    for col in FLAG_COLS:
        if col not in out.columns:
            out[col] = np.nan

    out["flag_sum"] = out[FLAG_COLS].sum(axis=1)
    out["flag_abs_sum"] = out[FLAG_COLS].abs().sum(axis=1)
    out["flag_max"] = out[FLAG_COLS].max(axis=1)
    out["flag_min"] = out[FLAG_COLS].min(axis=1)
    out["num_flags_nonzero"] = (out[FLAG_COLS] != 0).sum(axis=1).astype("int8")
    out["num_flags_bad_ge2"] = (out[FLAG_COLS] >= 2).sum(axis=1).astype("int8")
    out["num_flags_good_le0"] = (out[FLAG_COLS] <= 0).sum(axis=1).astype("int8")
    out["any_flag_bad_ge2"] = (out["num_flags_bad_ge2"] > 0).astype("int8")
    out["all_flags_goodish"] = ((out[FLAG_COLS] <= 1).all(axis=1)).astype("int8")

    return out


def build_measure_context(station_full: pd.DataFrame, measure: str) -> pd.DataFrame:
    if measure not in station_full.columns:
        return pd.DataFrame(columns=["Ob"])

    s = station_full[["Ob", measure]].copy()
    s = s.rename(columns={measure: "ctx_current"})
    s["ctx_current"] = pd.to_numeric(s["ctx_current"], errors="coerce")
    s = s.sort_values("Ob").reset_index(drop=True)

    for lag in LAG_STEPS:
        s[f"lag_{lag}"] = s["ctx_current"].shift(lag)
        s[f"delta_{lag}"] = s["ctx_current"] - s[f"lag_{lag}"]
        s[f"abs_delta_{lag}"] = s[f"delta_{lag}"].abs()

    prior = s["ctx_current"].shift(1)
    for w in ROLL_WINDOWS:
        roll = prior.rolling(window=w, min_periods=1)
        s[f"roll_mean_{w}"] = roll.mean()
        s[f"roll_std_{w}"] = roll.std()
        s[f"roll_min_{w}"] = roll.min()
        s[f"roll_max_{w}"] = roll.max()
        s[f"roll_range_{w}"] = s[f"roll_max_{w}"] - s[f"roll_min_{w}"]

        denom = s[f"roll_std_{w}"].replace(0, np.nan)
        s[f"z_from_mean_{w}"] = (s["ctx_current"] - s[f"roll_mean_{w}"]) / denom
        s[f"abs_z_from_mean_{w}"] = s[f"z_from_mean_{w}"].abs()

    return s


def resolve_station_path(full_dir: Path, station_name: str) -> Path:
    candidates = [
        full_dir / f"{station_name}.csv",
        full_dir / f"{station_name}_2021.csv",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate

    matches = sorted(full_dir.glob(f"{station_name}*.csv"))
    if matches:
        return matches[0]

    raise FileNotFoundError(
        f"Could not find station file for {station_name}. Tried: "
        + ", ".join(str(p) for p in candidates)
    )


def engineer_station(
    station_name: str,
    station_rows: pd.DataFrame,
    full_dir: Path,
    station_meta: Optional[pd.DataFrame] = None,
) -> pd.DataFrame:
    station_rows = station_rows.copy()
    station_rows = station_rows.sort_values("Ob").reset_index(drop=True)

    full_path = resolve_station_path(full_dir, station_name)
    station_full = pd.read_csv(full_path)
    station_full["Ob"] = pd.to_datetime(station_full["Ob"], errors="coerce")
    station_full = station_full.sort_values("Ob").reset_index(drop=True)

    engineered_parts: List[pd.DataFrame] = []
    for measure in station_rows["measure"].astype(str).unique():
        part = station_rows[station_rows["measure"].astype(str) == measure].copy()
        ctx = build_measure_context(station_full, measure)

        if ctx.empty:
            part["context_missing_measure"] = 1
            engineered_parts.append(part)
            continue

        part = part.merge(ctx, on="Ob", how="left")
        part["context_missing_measure"] = part["ctx_current"].isna().astype("int8")
        part["value_minus_ctx_current"] = part["value"] - part["ctx_current"]
        part["abs_value_minus_ctx_current"] = part["value_minus_ctx_current"].abs()
        engineered_parts.append(part)

    out = pd.concat(engineered_parts, ignore_index=True)

    if station_meta is not None and "Station" in station_meta.columns:
        out = out.merge(station_meta, on="Station", how="left")

    return out


def build_feature_tables(
    labeled_csv: Path,
    full_dir: Path,
    output_dir: Path,
    readme_xlsx: Optional[Path] = None,
) -> Dict[str, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)

    sample_cols = pd.read_csv(labeled_csv, nrows=0).columns.tolist()
    usecols = [c for c in BASE_USECOLS if c in sample_cols]
    labels = pd.read_csv(labeled_csv, usecols=usecols)
    labels["row_id"] = np.arange(len(labels), dtype=np.int64)
    labels = optimize_label_dtypes(labels)
    labels = add_base_features(labels)

    station_meta = load_station_metadata(readme_xlsx)

    engineered_station_paths: List[Path] = []
    for station_name, station_rows in labels.groupby("Station", observed=True, sort=False):
        station_name = str(station_name)
        station_out = engineer_station(
            station_name=station_name,
            station_rows=station_rows,
            full_dir=full_dir,
            station_meta=station_meta,
        )
        station_path = output_dir / "per_station" / f"{station_name}.parquet"
        engineered_station_paths.append(safe_write(station_out, station_path))

    frames = []
    for p in engineered_station_paths:
        if p.suffix == ".parquet":
            frames.append(pd.read_parquet(p))
        else:
            frames.append(pd.read_csv(p))
    full_features = pd.concat(frames, ignore_index=True)
    full_features = full_features.sort_values("row_id").reset_index(drop=True)

    passthrough_cols = [c for c in ["row_id", "Ob", "target"] if c in full_features.columns]
    base_feature_cols = [
        c
        for c in [
            "Station", "measure", "value", *FLAG_COLS,
            "hour", "dayofweek", "month", "dayofyear", "is_weekend",
            "hour_sin", "hour_cos", "doy_sin", "doy_cos",
            "flag_sum", "flag_abs_sum", "flag_max", "flag_min",
            "num_flags_nonzero", "num_flags_bad_ge2", "num_flags_good_le0",
            "any_flag_bad_ge2", "all_flags_goodish",
            "latitude_degrees_north", "longitude_degrees_east", "elevation_feet",
            "county", "city",
        ]
        if c in full_features.columns
    ]
    context_feature_cols = [
        c for c in full_features.columns
        if c.startswith(("lag_", "delta_", "abs_delta_", "roll_", "z_from_", "abs_z_", "ctx_"))
        or c in ["context_missing_measure", "value_minus_ctx_current", "abs_value_minus_ctx_current"]
    ]

    numeric_features = dedupe_keep_order([
        c for c in base_feature_cols + context_feature_cols + ["value"] + FLAG_COLS
        if c in full_features.columns and pd.api.types.is_numeric_dtype(full_features[c])
    ])
    categorical_features = dedupe_keep_order([
        c for c in ["Station", "measure", "county", "city"]
        if c in full_features.columns
    ])
    base_feature_cols = dedupe_keep_order(base_feature_cols)
    context_feature_cols = dedupe_keep_order(context_feature_cols)

    manifest = {
        "input_csv": str(labeled_csv),
        "full_dir": str(full_dir),
        "row_count": int(len(full_features)),
        "passthrough_columns": passthrough_cols,
        "base_feature_columns": base_feature_cols,
        "context_feature_columns": context_feature_cols,
        "categorical_features": categorical_features,
        "numeric_features": numeric_features,
        "target_column": "target" if "target" in full_features.columns else None,
        "notes": {
            "base_features": "Use for the no-context baseline comparison.",
            "full_features": "Use base_feature_columns + context_feature_columns for the context-rich model.",
            "leakage_guard": "All lag and rolling features are computed using only values at or before the reviewed timestamp, with rolling windows excluding the current observation.",
        },
    }

    manifest_path = output_dir / "feature_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    report = {
        "row_count": int(len(full_features)),
        "n_base_features": len(base_feature_cols),
        "n_context_features": len(context_feature_cols),
        "target_present": "target" in full_features.columns,
        "missing_fraction_top20": full_features.isna().mean().sort_values(ascending=False).head(20).to_dict(),
    }
    report_path = output_dir / "engineering_report.json"
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")

    preview_path = safe_write(full_features.head(2000), output_dir / "feature_preview.csv")
    full_table_path = safe_write(full_features, output_dir / "engineered_features.parquet")

    return {
        "engineered_features": full_table_path,
        "preview": preview_path,
        "manifest": manifest_path,
        "report": report_path,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="EcoNET feature engineering")
    parser.add_argument("--labeled_csv", type=Path, required=True, help="Path to cleaned train.csv or test.csv")
    parser.add_argument("--full_dir", type=Path, required=True, help="Path to full/ station CSV directory")
    parser.add_argument("--output_dir", type=Path, default=Path("./econet_features"))
    parser.add_argument("--readme_xlsx", type=Path, default=None, help="Optional path to ECONET_QC_Readme.xlsx")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    outputs = build_feature_tables(
        labeled_csv=args.labeled_csv,
        full_dir=args.full_dir,
        output_dir=args.output_dir,
        readme_xlsx=args.readme_xlsx,
    )
    print(json.dumps({k: str(v) for k, v in outputs.items()}, indent=2))


if __name__ == "__main__":
    main()

#ifndef _SCHED_H_
#define _SCHED_H_

/* scheduling classes */
#define EXPDISTSCHED 1
#define LINUXSCHED   2

/* API */
void setschedclass(int sched_class);
int  getschedclass(void);

/* provided in sys/math.c */
double expdev(double lambda);

#endif

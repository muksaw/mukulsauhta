#include <conf.h>
#include <kernel.h>
#include <sched.h>

static int g_sched_class = EXPDISTSCHED;

void setschedclass(int sched_class)
{
    STATWORD ps;
    disable(ps);
    g_sched_class = sched_class;
    restore(ps);
}

int getschedclass(void)
{
    STATWORD ps; int c;
    disable(ps);
    c = g_sched_class;
    restore(ps);
    return c;
}

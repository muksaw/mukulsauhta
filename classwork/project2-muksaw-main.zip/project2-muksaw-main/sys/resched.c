#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <q.h>
#include <sched.h>
#include <stdio.h>

unsigned long currSP;
extern int ctxsw(int, int, int, int);

/* ---------- EXP helper ---------- */
/* Choose the process with the smallest priority STRICTLY GREATER than r.
 * If r < lowest priority, choose the lowest.
 * If r >= highest priority, choose the highest. */
static int exp_pick_next(void)
{
    double r = expdev(0.1);
    int p;

    /* ready list is sorted; walk from head (low) to tail (high) */
    for (p = q[rdyhead].qnext; p != rdytail; p = q[p].qnext) {
        if (q[p].qkey > (int)r) break;           /* first key > r */
    }

    if (p == rdytail) {
        /* none > r -> pick highest (tail-1). getlast() dequeues it */
        return getlast(rdytail);
    }

    /* p is the earliest enqueued with the target priority; dequeue it */
    dequeue(p);
    return p;
}

/* ---------- Linux helpers ---------- */
static void linux_new_epoch(void)
{
    int i;
    for (i = 0; i < NPROC; i++) {
        if (proctab[i].pstate == PRFREE) continue;

        if (proctab[i].premaining == 0 || proctab[i].pquantum == 0)
            proctab[i].pquantum = proctab[i].pprio;
        else
            proctab[i].pquantum = proctab[i].pprio + (proctab[i].premaining / 2);

        proctab[i].premaining = proctab[i].pquantum;

        if (i == NULLPROC)
            proctab[i].pgoodness = 0;
        else
            proctab[i].pgoodness = proctab[i].premaining
                                  ? (proctab[i].pprio + proctab[i].premaining)
                                  : 0;
    }
    /* (debug epoch markers removed before submission) */
}

static int linux_pick_next(int curpid, int cur_is_running)
{
    int p, maxpid = -1, maxgood = 0;

    if (cur_is_running) {
        proctab[curpid].premaining = preempt;
        if (proctab[curpid].premaining <= 0) {
            proctab[curpid].premaining = 0;
            proctab[curpid].pgoodness  = 0;
        } else {
            proctab[curpid].pgoodness  = proctab[curpid].pprio + proctab[curpid].premaining;
        }
    }

    for (p = q[rdyhead].qnext; p != rdytail; p = q[p].qnext) {
        int g = proctab[p].pgoodness;
        if (g > maxgood) { maxgood = g; maxpid = p; }
    }

    if (cur_is_running) {
        if (proctab[curpid].pgoodness >= maxgood && proctab[curpid].pgoodness > 0)
            return curpid; /* keep running */
    }

    if (maxgood == 0) {
        linux_new_epoch();
        maxpid = -1; maxgood = 0;
        for (p = q[rdyhead].qnext; p != rdytail; p = q[p].qnext) {
            int g = proctab[p].pgoodness;
            if (g > maxgood) { maxgood = g; maxpid = p; }
        }
        if (maxgood == 0) return NULLPROC;
    }

    return maxpid;
}

/* ----------------- main resched ----------------- */
int resched(void)
{
    STATWORD ps;
    disable(ps);

    register struct pentry *optr = &proctab[currpid];
    register struct pentry *nptr;

    switch (getschedclass()) {

    case EXPDISTSCHED: {
        if (optr->pstate == PRCURR) {
            optr->pstate = PRREADY;
            insert(currpid, rdyhead, optr->pprio);
        }

        int pick;
        if (q[rdyhead].qnext == rdytail) {
            pick = NULLPROC;                /* only NULL is ready */
        } else {
            pick = exp_pick_next();         /* dequeues inside */
        }

        currpid = pick;
        nptr = &proctab[currpid];
        nptr->pstate = PRCURR;

#ifdef  RTCLOCK
        preempt = QUANTUM;                  /* fixed timeslice for EXP */
#endif
        ctxsw((int)&optr->pesp,(int)optr->pirmask,(int)&nptr->pesp,(int)nptr->pirmask);

        restore(ps);
        return OK;
    }

    case LINUXSCHED: {
        static int first_linux = 1;
        if (first_linux) {
            first_linux = 0;
            linux_new_epoch();              /* set pquantum/premaining/pgoodness */
#ifdef RTCLOCK
            /* make sure the current (main) process gets its full first quantum */
            preempt = proctab[currpid].premaining > 0 ? proctab[currpid].premaining : 1;
#endif
        }

        int keep_is_running = (optr->pstate == PRCURR);
        int next = linux_pick_next(currpid, keep_is_running);

        if (next == currpid && keep_is_running) {
#ifdef RTCLOCK
            preempt = proctab[currpid].premaining;
            if (preempt <= 0) preempt = 1;
#endif
            restore(ps);
            return OK;
        }

        if (optr->pstate == PRCURR) {
            optr->pstate = PRREADY;
            insert(currpid, rdyhead, optr->pprio);
        }

        if (next != NULLPROC) dequeue(next);
        currpid = next;
        nptr = &proctab[currpid];
        nptr->pstate = PRCURR;

#ifdef RTCLOCK
        if (nptr->premaining <= 0) nptr->premaining = 1;
        preempt = nptr->premaining;
#endif

        ctxsw((int)&optr->pesp,(int)optr->pirmask,(int)&nptr->pesp,(int)nptr->pirmask);

        restore(ps);
        return OK;
    }

    default: {  /* classic priority scheduler (never used by tests, but harmless) */
        if ((optr->pstate == PRCURR) && (lastkey(rdytail) < optr->pprio)) {
            restore(ps);
            return OK;
        }

        if (optr->pstate == PRCURR) {
            optr->pstate = PRREADY;
            insert(currpid, rdyhead, optr->pprio);
        }

        currpid = getlast(rdytail);
        nptr = &proctab[currpid];
        nptr->pstate = PRCURR;

#ifdef  RTCLOCK
        preempt = QUANTUM;
#endif
        ctxsw((int)&optr->pesp,(int)optr->pirmask,(int)&nptr->pesp,(int)nptr->pirmask);

        restore(ps);
        return OK;
    }
    }
}

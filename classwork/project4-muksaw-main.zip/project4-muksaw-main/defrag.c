#define _POSIX_C_SOURCE 200809L

#include <errno.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#define N_DBLOCKS 10
#define N_IBLOCKS 4

struct superblock {
    int32_t blocksize;
    int32_t inode_offset;
    int32_t data_offset;
    int32_t swap_offset;
    int32_t free_inode;
    int32_t free_block;
};

struct inode {
    int32_t next_inode;
    int32_t protect;
    int32_t nlink;
    int32_t size;
    int32_t uid;
    int32_t gid;
    int32_t ctime;
    int32_t mtime;
    int32_t atime;
    int32_t dblocks[N_DBLOCKS];
    int32_t iblocks[N_IBLOCKS];
    int32_t i2block;
    int32_t i3block;
};

_Static_assert(sizeof(struct superblock) == 24, "superblock must be 24 bytes");
_Static_assert(sizeof(struct inode) == 100, "inode must be 100 bytes");

static void die(const char *fmt, ...) __attribute__((cold));
static void die(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(EXIT_FAILURE);
}

static void *xmalloc(size_t size)
{
    void *ptr = malloc(size);
    if (!ptr) {
        die("malloc failed for %zu bytes", size);
    }
    return ptr;
}

static void read_disk_image(const char *path, unsigned char **buffer, size_t *size_out)
{
    FILE *fp = fopen(path, "rb");
    if (!fp) {
        die("failed to open '%s': %s", path, strerror(errno));
    }

    struct stat st;
    if (fstat(fileno(fp), &st) != 0) {
        fclose(fp);
        die("fstat failed for '%s': %s", path, strerror(errno));
    }

    if (st.st_size <= 0) {
        fclose(fp);
        die("disk image '%s' is empty", path);
    }

    size_t size = (size_t)st.st_size;
    unsigned char *buf = xmalloc(size);

    size_t read_bytes = fread(buf, 1, size, fp);
    if (read_bytes != size) {
        fclose(fp);
        free(buf);
        die("failed to read disk image '%s': expected %zu bytes, got %zu", path, size, read_bytes);
    }

    fclose(fp);
    *buffer = buf;
    *size_out = size;
}

static void write_disk_image(const char *path, const unsigned char *buffer, size_t size)
{
    FILE *fp = fopen(path, "wb");
    if (!fp) {
        die("failed to create '%s': %s", path, strerror(errno));
    }

    size_t written = fwrite(buffer, 1, size, fp);
    if (written != size) {
        fclose(fp);
        die("failed to write full disk image '%s'", path);
    }

    if (fclose(fp) != 0) {
        die("failed to close '%s': %s", path, strerror(errno));
    }
}

static inline int32_t read_le32(const unsigned char *p)
{
    return (int32_t)((uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24));
}

static inline void write_le32(unsigned char *p, int32_t v)
{
    uint32_t u = (uint32_t)v;
    p[0] = (unsigned char)(u & 0xFF);
    p[1] = (unsigned char)((u >> 8) & 0xFF);
    p[2] = (unsigned char)((u >> 16) & 0xFF);
    p[3] = (unsigned char)((u >> 24) & 0xFF);
}

static void load_superblock(const unsigned char *buffer, struct superblock *sb)
{
    const unsigned char *base = buffer + 512; /* superblock begins after boot block */
    sb->blocksize = read_le32(base + 0);
    sb->inode_offset = read_le32(base + 4);
    sb->data_offset = read_le32(base + 8);
    sb->swap_offset = read_le32(base + 12);
    sb->free_inode = read_le32(base + 16);
    sb->free_block = read_le32(base + 20);
}

static void store_superblock(unsigned char *buffer, const struct superblock *sb)
{
    unsigned char *base = buffer + 512;
    memset(base, 0, 512);
    write_le32(base + 0, sb->blocksize);
    write_le32(base + 4, sb->inode_offset);
    write_le32(base + 8, sb->data_offset);
    write_le32(base + 12, sb->swap_offset);
    write_le32(base + 16, sb->free_inode);
    write_le32(base + 20, sb->free_block);
}

static void load_inode(const unsigned char *ptr, struct inode *node)
{
    const unsigned char *p = ptr;
    node->next_inode = read_le32(p); p += 4;
    node->protect = read_le32(p); p += 4;
    node->nlink = read_le32(p); p += 4;
    node->size = read_le32(p); p += 4;
    node->uid = read_le32(p); p += 4;
    node->gid = read_le32(p); p += 4;
    node->ctime = read_le32(p); p += 4;
    node->mtime = read_le32(p); p += 4;
    node->atime = read_le32(p); p += 4;
    for (int i = 0; i < N_DBLOCKS; ++i, p += 4) {
        node->dblocks[i] = read_le32(p);
    }
    for (int i = 0; i < N_IBLOCKS; ++i, p += 4) {
        node->iblocks[i] = read_le32(p);
    }
    node->i2block = read_le32(p); p += 4;
    node->i3block = read_le32(p);
}

static void store_inode(unsigned char *ptr, const struct inode *node)
{
    unsigned char *p = ptr;
    write_le32(p, node->next_inode); p += 4;
    write_le32(p, node->protect); p += 4;
    write_le32(p, node->nlink); p += 4;
    write_le32(p, node->size); p += 4;
    write_le32(p, node->uid); p += 4;
    write_le32(p, node->gid); p += 4;
    write_le32(p, node->ctime); p += 4;
    write_le32(p, node->mtime); p += 4;
    write_le32(p, node->atime); p += 4;
    for (int i = 0; i < N_DBLOCKS; ++i, p += 4) {
        write_le32(p, node->dblocks[i]);
    }
    for (int i = 0; i < N_IBLOCKS; ++i, p += 4) {
        write_le32(p, node->iblocks[i]);
    }
    write_le32(p, node->i2block); p += 4;
    write_le32(p, node->i3block);
}

static size_t get_inode_region_start(const struct superblock *sb)
{
    return 512u + 512u + (size_t)sb->inode_offset * (size_t)sb->blocksize;
}

static size_t get_data_region_start(const struct superblock *sb)
{
    return 512u + 512u + (size_t)sb->data_offset * (size_t)sb->blocksize;
}

static size_t get_swap_region_start(const struct superblock *sb)
{
    return 512u + 512u + (size_t)sb->swap_offset * (size_t)sb->blocksize;
}

static size_t inode_count_from_region(size_t inode_region_size)
{
    return inode_region_size / sizeof(struct inode);
}

static size_t blocks_per_level(size_t blocksize)
{
    size_t per = blocksize / sizeof(int32_t);
    if (per == 0) {
        die("block size %zu too small to contain pointers", blocksize);
    }
    return per;
}

static void validate_block_index(int32_t index, size_t total_blocks, const char *what)
{
    if (index < 0 || (size_t)index >= total_blocks) {
        die("invalid %s index %d (total blocks %zu)", what, index, total_blocks);
    }
}

static size_t collect_data_blocks_direct(const struct inode *node, int32_t *out, size_t needed, size_t total_blocks)
{
    size_t count = 0;
    for (int i = 0; i < N_DBLOCKS && count < needed; ++i) {
        int32_t idx = node->dblocks[i];
        if (idx >= 0) {
            validate_block_index(idx, total_blocks, "data");
            out[count++] = idx;
        }
    }
    return count;
}

static void collect_from_single_indirect(const unsigned char *data_region, size_t blocksize, size_t total_blocks,
                                         int32_t block_index, int32_t *out, size_t *count, size_t needed)
{
    size_t ptrs_per_block = blocks_per_level(blocksize);
    validate_block_index(block_index, total_blocks, "single indirect");
    const unsigned char *block = data_region + (size_t)block_index * blocksize;
    for (size_t i = 0; i < ptrs_per_block && *count < needed; ++i) {
        int32_t val = read_le32(block + i * sizeof(int32_t));
        if (val == -1) {
            break;
        }
        validate_block_index(val, total_blocks, "data");
        out[(*count)++] = val;
    }
}

static void collect_from_double_indirect(const unsigned char *data_region, size_t blocksize, size_t total_blocks,
                                         int32_t block_index, int32_t *out, size_t *count, size_t needed)
{
    size_t ptrs_per_block = blocks_per_level(blocksize);
    validate_block_index(block_index, total_blocks, "double indirect");
    const unsigned char *block = data_region + (size_t)block_index * blocksize;
    for (size_t i = 0; i < ptrs_per_block && *count < needed; ++i) {
        int32_t single = read_le32(block + i * sizeof(int32_t));
        if (single == -1) {
            break;
        }
        collect_from_single_indirect(data_region, blocksize, total_blocks, single, out, count, needed);
    }
}

static void collect_from_triple_indirect(const unsigned char *data_region, size_t blocksize, size_t total_blocks,
                                         int32_t block_index, int32_t *out, size_t *count, size_t needed)
{
    size_t ptrs_per_block = blocks_per_level(blocksize);
    validate_block_index(block_index, total_blocks, "triple indirect");
    const unsigned char *block = data_region + (size_t)block_index * blocksize;
    for (size_t i = 0; i < ptrs_per_block && *count < needed; ++i) {
        int32_t dbl = read_le32(block + i * sizeof(int32_t));
        if (dbl == -1) {
            break;
        }
        collect_from_double_indirect(data_region, blocksize, total_blocks, dbl, out, count, needed);
    }
}

static void collect_data_blocks(const unsigned char *data_region, size_t blocksize, size_t total_blocks,
                                const struct inode *node, int32_t *data_blocks, size_t needed)
{
    size_t count = 0;
    count += collect_data_blocks_direct(node, data_blocks, needed, total_blocks);

    for (int i = 0; i < N_IBLOCKS && count < needed; ++i) {
        if (node->iblocks[i] >= 0) {
            collect_from_single_indirect(data_region, blocksize, total_blocks, node->iblocks[i], data_blocks, &count, needed);
        }
    }

    if (count < needed && node->i2block >= 0) {
        collect_from_double_indirect(data_region, blocksize, total_blocks, node->i2block, data_blocks, &count, needed);
    }

    if (count < needed && node->i3block >= 0) {
        collect_from_triple_indirect(data_region, blocksize, total_blocks, node->i3block, data_blocks, &count, needed);
    }

    if (count != needed) {
        die("inode reports %zu data blocks but %zu located", needed, count);
    }
}

static int32_t allocate_block_index(size_t total_blocks, size_t *next_block)
{
    if (*next_block >= total_blocks) {
        die("out of data blocks while defragmenting");
    }
    return (int32_t)(*next_block)++;
}

static void fill_block_with_minus_one(unsigned char *block, size_t blocksize)
{
    size_t entries = blocks_per_level(blocksize);
    for (size_t i = 0; i < entries; ++i) {
        write_le32(block + i * sizeof(int32_t), -1);
    }
}

static void copy_data_block(const unsigned char *input_data_region, unsigned char *output_data_region,
                            size_t blocksize, int32_t src_index, int32_t dst_index)
{
    const unsigned char *src = input_data_region + (size_t)src_index * blocksize;
    unsigned char *dst = output_data_region + (size_t)dst_index * blocksize;
    memcpy(dst, src, blocksize);
}

static void defragment_inode(const unsigned char *input_data_region, unsigned char *output_data_region,
                             size_t blocksize, size_t total_blocks, struct inode *node,
                             size_t *next_block, int32_t *scratch_blocks)
{
    if (node->nlink == 0) {
        return;
    }

    size_t num_data_blocks = (node->size <= 0) ? 0 : (1 + ((size_t)node->size - 1) / blocksize);
    if (num_data_blocks == 0) {
        for (int i = 0; i < N_DBLOCKS; ++i) {
            node->dblocks[i] = -1;
        }
        for (int i = 0; i < N_IBLOCKS; ++i) {
            node->iblocks[i] = -1;
        }
        node->i2block = -1;
        node->i3block = -1;
        return;
    }

    collect_data_blocks(input_data_region, blocksize, total_blocks, node, scratch_blocks, num_data_blocks);

    for (int i = 0; i < N_DBLOCKS; ++i) {
        node->dblocks[i] = -1;
    }
    for (int i = 0; i < N_IBLOCKS; ++i) {
        node->iblocks[i] = -1;
    }
    node->i2block = -1;
    node->i3block = -1;

    size_t data_pos = 0;
    size_t ptrs_per_block = blocks_per_level(blocksize);

    /* Direct blocks */
    for (int i = 0; i < N_DBLOCKS && data_pos < num_data_blocks; ++i) {
        int32_t new_idx = allocate_block_index(total_blocks, next_block);
        node->dblocks[i] = new_idx;
        copy_data_block(input_data_region, output_data_region, blocksize,
                        scratch_blocks[data_pos], new_idx);
        ++data_pos;
    }

    /* Single indirect blocks */
    for (int i = 0; i < N_IBLOCKS && data_pos < num_data_blocks; ++i) {
        size_t remaining = num_data_blocks - data_pos;
        size_t to_assign = remaining < ptrs_per_block ? remaining : ptrs_per_block;
        int32_t ptr_block_index = allocate_block_index(total_blocks, next_block);
        node->iblocks[i] = ptr_block_index;
        unsigned char *ptr_block = output_data_region + (size_t)ptr_block_index * blocksize;
        fill_block_with_minus_one(ptr_block, blocksize);
        for (size_t j = 0; j < to_assign; ++j) {
            int32_t data_block_index = allocate_block_index(total_blocks, next_block);
            write_le32(ptr_block + j * sizeof(int32_t), data_block_index);
            copy_data_block(input_data_region, output_data_region, blocksize,
                            scratch_blocks[data_pos], data_block_index);
            ++data_pos;
        }
    }

    /* Double indirect blocks */
    if (data_pos < num_data_blocks) {
        int32_t double_block_index = allocate_block_index(total_blocks, next_block);
        node->i2block = double_block_index;
        unsigned char *double_block = output_data_region + (size_t)double_block_index * blocksize;
        fill_block_with_minus_one(double_block, blocksize);
        for (size_t i = 0; i < ptrs_per_block && data_pos < num_data_blocks; ++i) {
            int32_t single_block_index = allocate_block_index(total_blocks, next_block);
            write_le32(double_block + i * sizeof(int32_t), single_block_index);
            unsigned char *single_block = output_data_region + (size_t)single_block_index * blocksize;
            fill_block_with_minus_one(single_block, blocksize);
            size_t remaining = num_data_blocks - data_pos;
            size_t to_assign = remaining < ptrs_per_block ? remaining : ptrs_per_block;
            for (size_t j = 0; j < to_assign; ++j) {
                int32_t data_block_index = allocate_block_index(total_blocks, next_block);
                write_le32(single_block + j * sizeof(int32_t), data_block_index);
                copy_data_block(input_data_region, output_data_region, blocksize,
                                scratch_blocks[data_pos], data_block_index);
                ++data_pos;
            }
        }
    }

    /* Triple indirect blocks */
    if (data_pos < num_data_blocks) {
        int32_t triple_block_index = allocate_block_index(total_blocks, next_block);
        node->i3block = triple_block_index;
        unsigned char *triple_block = output_data_region + (size_t)triple_block_index * blocksize;
        fill_block_with_minus_one(triple_block, blocksize);
        for (size_t i = 0; i < ptrs_per_block && data_pos < num_data_blocks; ++i) {
            int32_t double_block_index = allocate_block_index(total_blocks, next_block);
            write_le32(triple_block + i * sizeof(int32_t), double_block_index);
            unsigned char *double_block = output_data_region + (size_t)double_block_index * blocksize;
            fill_block_with_minus_one(double_block, blocksize);
            for (size_t j = 0; j < ptrs_per_block && data_pos < num_data_blocks; ++j) {
                int32_t single_block_index = allocate_block_index(total_blocks, next_block);
                write_le32(double_block + j * sizeof(int32_t), single_block_index);
                unsigned char *single_block = output_data_region + (size_t)single_block_index * blocksize;
                fill_block_with_minus_one(single_block, blocksize);
                size_t remaining = num_data_blocks - data_pos;
                size_t to_assign = remaining < ptrs_per_block ? remaining : ptrs_per_block;
                for (size_t k = 0; k < to_assign; ++k) {
                    int32_t data_block_index = allocate_block_index(total_blocks, next_block);
                    write_le32(single_block + k * sizeof(int32_t), data_block_index);
                    copy_data_block(input_data_region, output_data_region, blocksize,
                                    scratch_blocks[data_pos], data_block_index);
                    ++data_pos;
                }
            }
        }
    }

    if (data_pos != num_data_blocks) {
        die("failed to assign all data blocks to inode (assigned %zu of %zu)", data_pos, num_data_blocks);
    }
}

static void populate_free_blocks(unsigned char *data_region, size_t blocksize, size_t total_blocks, size_t start_index, int32_t *head_out)
{
    if (start_index >= total_blocks) {
        *head_out = -1;
        return;
    }

    for (size_t idx = start_index; idx < total_blocks; ++idx) {
        unsigned char *block = data_region + idx * blocksize;
        memset(block, 0, blocksize);
        int32_t next = (idx + 1 < total_blocks) ? (int32_t)(idx + 1) : -1;
        write_le32(block, next);
    }
    *head_out = (int32_t)start_index;
}

int main(int argc, char *argv[])
{
    if (argc != 2) {
        die("usage: %s <disk_image>", argv[0]);
    }

    const char *input_path = argv[1];
    const char *output_path = "disk_defrag";

    unsigned char *input_buffer = NULL;
    size_t disk_size = 0;
    read_disk_image(input_path, &input_buffer, &disk_size);

    struct superblock sb;
    load_superblock(input_buffer, &sb);

    if (sb.blocksize <= 0) {
        free(input_buffer);
        die("invalid block size %d", sb.blocksize);
    }

    size_t blocksize = (size_t)sb.blocksize;
    size_t inode_region_start = get_inode_region_start(&sb);
    size_t data_region_start = get_data_region_start(&sb);
    size_t swap_region_start = get_swap_region_start(&sb);

    if (swap_region_start > disk_size) {
        free(input_buffer);
        die("swap region offset beyond disk image");
    }

    if (data_region_start < inode_region_start) {
        free(input_buffer);
        die("data region begins before inode region");
    }

    size_t inode_region_size = data_region_start - inode_region_start;
    size_t data_region_size = swap_region_start - data_region_start;
    size_t total_blocks = (blocksize == 0) ? 0 : data_region_size / blocksize;

    if (total_blocks * blocksize != data_region_size) {
        free(input_buffer);
        die("data region size not aligned to block size");
    }

    size_t inode_count = inode_count_from_region(inode_region_size);

    unsigned char *output_buffer = xmalloc(disk_size);
    memcpy(output_buffer, input_buffer, 512); /* copy boot block */

    unsigned char *new_inode_region = output_buffer + inode_region_start;
    memset(new_inode_region, 0, inode_region_size);

    unsigned char *new_data_region = output_buffer + data_region_start;
    memset(new_data_region, 0, data_region_size);

    /* swap region copied later */

    const unsigned char *input_inode_region = input_buffer + inode_region_start;
    const unsigned char *input_data_region = input_buffer + data_region_start;

    size_t next_block = 0;
    size_t scratch_capacity = (total_blocks > 0) ? total_blocks : 1;
    int32_t *scratch_blocks = xmalloc(scratch_capacity * sizeof(int32_t));

    for (size_t i = 0; i < inode_count; ++i) {
        const unsigned char *src = input_inode_region + i * sizeof(struct inode);
        unsigned char *dst = new_inode_region + i * sizeof(struct inode);

        struct inode node;
        load_inode(src, &node);

        if (node.nlink != 0) {
            size_t data_blocks_needed = (node.size <= 0) ? 0 : (1 + ((size_t)node.size - 1) / blocksize);
            if (data_blocks_needed > total_blocks) {
                free(input_buffer);
                free(output_buffer);
                free(scratch_blocks);
                die("inode requires more data blocks (%zu) than available (%zu)", data_blocks_needed, total_blocks);
            }
            defragment_inode(input_data_region, new_data_region, blocksize, total_blocks, &node, &next_block, scratch_blocks);
        }

        store_inode(dst, &node);
    }

    int32_t free_block_head = -1;
    populate_free_blocks(new_data_region, blocksize, total_blocks, next_block, &free_block_head);

    struct superblock new_sb = sb;
    new_sb.free_block = free_block_head;

    store_superblock(output_buffer, &new_sb);

    size_t swap_size = disk_size - swap_region_start;
    memcpy(output_buffer + swap_region_start, input_buffer + swap_region_start, swap_size);

    write_disk_image(output_path, output_buffer, disk_size);

    free(scratch_blocks);
    free(output_buffer);
    free(input_buffer);

    return 0;
}


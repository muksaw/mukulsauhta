Build:
    make

Run:
    ./defrag <input_disk_image>

Output:
    The program writes the defragmented image to disk_defrag in the
    current directory. Ensure the input image is accessible before
    running the program.


/* scount.c - scount */

#include <conf.h>
#include <kernel.h>
#include <sem.h>
#include <lab0.h>

/*------------------------------------------------------------------------
 *  scount  --  return a semaphore count
 *------------------------------------------------------------------------
 */
SYSCALL scount(int sem)
{
	SYSCALL_START();
extern	struct	sentry	semaph[];

	if (isbadsem(sem) || semaph[sem].sstate==SFREE) {
		SYSCALL_END(S_SCOUNT);
		return(SYSERR);
	}

	SYSCALL_END(S_SCOUNT);
	return(semaph[sem].semcnt);
}

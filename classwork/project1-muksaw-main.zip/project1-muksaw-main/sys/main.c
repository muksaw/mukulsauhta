#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>
#include <lab0.h>

/*------------------------------------------------------------------------
 *  main  --  user main program
 *------------------------------------------------------------------------
 */
int main()
{

	kprintf("\n\nHello CSC 501\n\n");
	kprintf("Task 1 (zfunction)\n");
	long in  = 0xaabbccdd;
    	long out = zfunction(in);
    	kprintf("0x%08x => 0x%08x\n", (unsigned)in, (unsigned)out);

	kprintf("Task 2 (printprocstks)\n");
	printprocstks(10);

	
	/* simple worker */
	void prch(char c) { sleep(5); }

	kprintf("Task 3 (printsyscallsummary)\n");
	syscallsummary_start();
	resume(create(prch, 2000, 20, "proc X", 1, 'A'));
	sleep(10);
	syscallsummary_stop();
	printsyscallsummary();



	return 0;
}

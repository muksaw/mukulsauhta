#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>

/* Read current stack pointer from %esp */
static unsigned long curr_sp(void) {
    unsigned long sp;
    asm("movl %%esp, %0" : "=r"(sp));
    return sp;
}

/* Print stacks for all non-free processes with pprio > priority */
void printprocstks(int priority)
{
    int pid;
    for (pid = 0; pid < NPROC; pid++) {
        struct pentry *p = &proctab[pid];

        if (p->pstate == PRFREE)   continue;      /* skip free slots   */
        if (p->pprio  <= priority) continue;      /* threshold filter  */

        /* Use live %esp for the current process; saved pesp for others */
        unsigned long sp = (pid == currpid) ? curr_sp()
                                            : (unsigned long)p->pesp;

        kprintf("Process [%s]\n", p->pname);
        kprintf("    pid: %d\n", pid);
        kprintf("    priority: %d\n", p->pprio);
        kprintf("    base: 0x%08x\n", (unsigned)p->pbase);
        kprintf("    limit: 0x%08x\n", (unsigned)p->plimit);
        kprintf("    len: %d\n", (int)p->pstklen);
        kprintf("    pointer: 0x%08x\n\n", (unsigned)sp);
    }
}

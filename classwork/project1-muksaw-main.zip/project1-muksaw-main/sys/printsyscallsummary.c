#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>
#include <lab0.h>

/* globalss */
int sys_trace_on = 0;
struct scstat sysstats[NPROC][NSYSCALLS];

/* names aligned with the enum order */
static char *syscallnames[NSYSCALLS] = {
    "freemem","chprio","getpid","getprio","gettime","kill","receive",
    "recvclr","recvtim","resume","scount","sdelete","send","setdev",
    "setnok","screate","signal","signaln","sleep","sleep10","sleep100",
    "sleep1000","sreset","stacktrace","suspend","unsleep","wait"
};

void syscallsummary_start(void) {
    int i, j;
    for (i = 0; i < NPROC; i++)
        for (j = 0; j < NSYSCALLS; j++)
            sysstats[i][j].count = sysstats[i][j].total_ms = 0;
    sys_trace_on = 1;
}

void syscallsummary_stop(void) {
    sys_trace_on = 0;
}

void printsyscallsummary(void) {
    int pid, sid;

    for (pid = 0; pid < NPROC; pid++) {
        int printed = 0;

        for (sid = 0; sid < NSYSCALLS; sid++) {
            if (sysstats[pid][sid].count) { printed = 1; break; }
        }
        if (!printed) continue;

        kprintf("Process [pid:%d]\n", pid);
        for (sid = 0; sid < NSYSCALLS; sid++) {
            unsigned long c = sysstats[pid][sid].count;
            if (!c) continue;
            unsigned long avg = sysstats[pid][sid].total_ms / c;
            kprintf("    Syscall: sys_%s, count: %lu, average execution time: %lu (ms)\n",
                    syscallnames[sid], c, avg);
        }
        kprintf("\n");
    }
}

#ifndef _LAB0_H_
#define _LAB0_H_

extern long zfunction(long param);

extern void printprocstks(int priority);

#include <proc.h>   
#include <kernel.h> 

#define NSYSCALLS 27

enum {
    S_FREEMEM=0, S_CHPRIO, S_GETPID, S_GETPRIO, S_GETTIME, S_KILL, S_RECEIVE,
    S_RECVCLR, S_RECVTIM, S_RESUME, S_SCOUNT, S_SDELETE, S_SEND, S_SETDEV,
    S_SETNOK, S_SCREATE, S_SIGNAL, S_SIGNALN, S_SLEEP, S_SLEEP10, S_SLEEP100,
    S_SLEEP1000, S_SRESET, S_STACKTRACE, S_SUSPEND, S_UNSLEEP, S_WAIT
};

/* per-syscall stats */
struct scstat { unsigned long count; unsigned long total_ms; };


/* Globals (defined in printsyscallsummary.c) */
extern int sys_trace_on;
extern struct scstat sysstats[NPROC][NSYSCALLS];

/* API */
void syscallsummary_start(void);
void syscallsummary_stop(void);
void printsyscallsummary(void);

extern int ctr1000;
/* Lightweight macros to instrument at entry/exit */
#define SYSCALL_START() unsigned long __t0 = ctr1000
#define SYSCALL_END(SID) do { \
    if (sys_trace_on) { \
        struct scstat *st = &sysstats[currpid][(SID)]; \
        st->count++; \
        st->total_ms += (ctr1000 - __t0); \
    } \
} while (0)

#endif


/* vgetmem.c - vgetmem */

#include <conf.h>
#include <kernel.h>
#include <mem.h>
#include <proc.h>
#include <paging.h>

extern struct pentry proctab[];
/*------------------------------------------------------------------------
 * vgetmem - allocate virtual heap storage, returning lowest WORD address
 *------------------------------------------------------------------------
 */
WORD	*vgetmem(nbytes)
	unsigned nbytes;
{
	struct	mblock	*p, *q, *leftover;
	struct	pentry	*pptr;
	unsigned long	vaddr;
	
	/* Check if current process has a virtual heap */
	pptr = &proctab[currpid];
	if (pptr->store == -1) {
		kprintf("vgetmem: Process %d has no virtual heap\n", currpid);
		return (WORD *)SYSERR;
	}
	
	/* Round up to word boundary */
	nbytes = (unsigned) roundew(nbytes);
	if (nbytes == 0) {
		return (WORD *)SYSERR;
	}
	
	/* Check if requested size exceeds heap size */
	unsigned long heap_size = pptr->vhpnpages * NBPG;
	if (nbytes > heap_size) {
		return (WORD *)SYSERR;
	}
	
	/* Initialize heap on first use (vmemlist == 1 is sentinel from vcreate) */
	if (pptr->vmemlist == (struct mblock *) 1) {
		unsigned long heap_start = pptr->vhpno * NBPG;
		pptr->vmemlist = (struct mblock *) heap_start;
		pptr->vmemlist->mnext = NULL;
		pptr->vmemlist->mlen = heap_size;
	}
	
	/* Check if heap is fully allocated (no free blocks) */
	if (pptr->vmemlist == NULL) {
		return (WORD *)SYSERR;
	}
	
	/* Search for a block large enough */
	q = NULL;
	p = pptr->vmemlist;
	while (p != NULL) {
		if (p->mlen == nbytes) {
			/* Exact fit - remove block from list */
			if (q == NULL) {
				pptr->vmemlist = p->mnext;
			} else {
				q->mnext = p->mnext;
			}
			vaddr = (unsigned long)p;
			return (WORD *)vaddr;
		}
		if (p->mlen > nbytes) {
			/* Split block - allocate from front, leave remainder */
			leftover = (struct mblock *)((unsigned)p + nbytes);
			leftover->mnext = p->mnext;
			leftover->mlen = p->mlen - nbytes;
			if (q == NULL) {
				pptr->vmemlist = leftover;
			} else {
				q->mnext = leftover;
			}
			vaddr = (unsigned long)p;
			return (WORD *)vaddr;
		}
		q = p;
		p = p->mnext;
	}
	
	/* No block found */
	return (WORD *)SYSERR;
}



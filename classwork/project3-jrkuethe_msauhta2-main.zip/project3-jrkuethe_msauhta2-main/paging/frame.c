/* frame.c - manage physical frames */
#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <paging.h>

/* Global variables for Second-Chance replacement policy */
static int sc_queue[NFRAMES];	/* Circular queue for Second-Chance */
static int sc_head = 0;		/* Head of the queue */
static int sc_tail = 0;		/* Tail of the queue */
static int sc_size = 0;		/* Current size of queue */

/* Debug flag for page replacement */
int pr_debug = 0;

/* External functions */
extern void write_cr3(unsigned long);
extern void invlpg(unsigned long);

/*-------------------------------------------------------------------------
 * init_frm - initialize frm_tab (the inverted page table)
 *-------------------------------------------------------------------------
 */
SYSCALL init_frm()
{
	int i;
	
	/* Initialize all frame entries as unmapped */
	for (i = 0; i < NFRAMES; i++) {
		frm_tab[i].fr_status = FRM_UNMAPPED;
		frm_tab[i].fr_pid = -1;
		frm_tab[i].fr_vpno = -1;
		frm_tab[i].fr_refcnt = 0;
		frm_tab[i].fr_type = FR_PAGE;
		frm_tab[i].fr_dirty = 0;
	}
	
	/* Initialize Second-Chance queue */
	sc_head = 0;
	sc_tail = 0;
	sc_size = 0;
	
	return OK;
}

/*-------------------------------------------------------------------------
 * get_frm - get a free frame according page replacement policy
 * 
 * out variables: avail
 * 
 * If a frame is available, return OK and set avail to the available frame.
 * 
 * If no frames are available, return SYSERR and set avail to any value or 
 * not set it at all, since callers should always check the return code prior 
 * to making use of out variables.
 *-------------------------------------------------------------------------
 */
SYSCALL get_frm(int* avail)
{
	int i;
	int frame_to_replace;
	int vp, p, q, pid, store, pageth;
	unsigned long a;
	pd_t *pd;
	pt_t *pt;
	int pt_frame_id;
	unsigned long page_addr;
	
	/* First, try to find a completely free frame */
	for (i = 0; i < NFRAMES; i++) {
		if (frm_tab[i].fr_status == FRM_UNMAPPED) {
			*avail = i;
			/* Add frame to SC queue if it's a page frame */
			if (frm_tab[i].fr_type == FR_PAGE) {
				sc_queue[sc_tail] = i;
				sc_tail = (sc_tail + 1) % NFRAMES;
				if (sc_size < NFRAMES) sc_size++;
			}
			return OK;
		}
	}
	
	/* No free frames - need to use Second-Chance replacement */
	/* Only replace PAGE frames, not page tables or directories */
	int attempts = 0;
	int max_attempts = NFRAMES * 2;  /* Allow two full passes */
	
	while (attempts < max_attempts) {
		if (sc_size == 0) {
			/* No frames in queue, shouldn't happen */
			return SYSERR;
		}
		
		frame_to_replace = sc_queue[sc_head];
		
		/* Skip if this is not a page frame (directory or table) */
		if (frm_tab[frame_to_replace].fr_type != FR_PAGE) {
			sc_head = (sc_head + 1) % NFRAMES;
			attempts++;
			continue;
		}
		
		/* Get the process and virtual page info */
		pid = frm_tab[frame_to_replace].fr_pid;
		vp = frm_tab[frame_to_replace].fr_vpno;
		a = vp * NBPG;
		p = (a >> 22) & 0x3FF;
		q = (a >> 12) & 0x3FF;
		
		/* Get page directory and page table */
		pd = (pd_t *) proctab[pid].pdbr;
		if (pd == 0 || pd[p].pd_pres == 0) {
			/* Invalid, just take this frame */
			sc_head = (sc_head + 1) % NFRAMES;
			break;
		}
		
		pt = (pt_t *) (pd[p].pd_base * NBPG);
		
		/* Check reference bit (accessed bit) */
		if (pt[q].pt_acc == 1) {
			/* Second chance - clear reference bit and move to next */
			pt[q].pt_acc = 0;
			sc_head = (sc_head + 1) % NFRAMES;
			attempts++;
			continue;
		}
		
		/* This frame can be replaced */
		sc_head = (sc_head + 1) % NFRAMES;
		break;
	}
	
	if (attempts >= max_attempts) {
		return SYSERR;
	}
	
	/* Now evict the frame */
	frame_to_replace = sc_queue[(sc_head - 1 + NFRAMES) % NFRAMES];
	pid = frm_tab[frame_to_replace].fr_pid;
	vp = frm_tab[frame_to_replace].fr_vpno;
	a = vp * NBPG;
	p = (a >> 22) & 0x3FF;
	q = (a >> 12) & 0x3FF;
	
	pd = (pd_t *) proctab[pid].pdbr;
	pt = (pt_t *) (pd[p].pd_base * NBPG);
	pt_frame_id = pd[p].pd_base - FRAME0;
	
	/* Mark page table entry as not present */
	pt[q].pt_pres = 0;
	
	/* If this page belongs to current process, invalidate TLB */
	if (pid == currpid) {
		asm("invlpg (%0)" : : "r" (a));
	}
	
	/* Decrement reference count of page table */
	frm_tab[pt_frame_id].fr_refcnt--;
	if (frm_tab[pt_frame_id].fr_refcnt == 0) {
		/* Page table is now empty, mark PD entry as not present */
		pd[p].pd_pres = 0;
	}
	
	/* If page is dirty, write it back to backing store */
	if (pt[q].pt_dirty == 1) {
		if (bsm_lookup(pid, a, &store, &pageth) == SYSERR) {
			kprintf("get_frm: Cannot find backing store for page\n");
			return SYSERR;
		}
		page_addr = (FRAME0 + frame_to_replace) * NBPG;
		write_bs((char *)page_addr, store, pageth);
	}
	
	/* Print debug info if enabled */
	if (pr_debug) {
		kprintf("Replaced frame %d\n", frame_to_replace);
	}
	
	*avail = frame_to_replace;
	return OK;
}

/*-------------------------------------------------------------------------
 * free_frm - free frame i
 *-------------------------------------------------------------------------
 */
SYSCALL free_frm(int i)
{
	/* Check if frame index is valid */
	if (i < 0 || i >= NFRAMES) {
		return SYSERR;
	}
	
	/* Mark frame as unmapped */
	frm_tab[i].fr_status = FRM_UNMAPPED;
	frm_tab[i].fr_pid = -1;
	frm_tab[i].fr_vpno = -1;
	frm_tab[i].fr_refcnt = 0;
	frm_tab[i].fr_type = FR_PAGE;
	frm_tab[i].fr_dirty = 0;
	
	return OK;
}




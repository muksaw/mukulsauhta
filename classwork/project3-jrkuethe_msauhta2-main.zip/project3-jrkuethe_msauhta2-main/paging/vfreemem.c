/* vfreemem.c - vfreemem */

#include <conf.h>
#include <kernel.h>
#include <mem.h>
#include <proc.h>
#include <paging.h>

extern struct pentry proctab[];
/*------------------------------------------------------------------------
 * vfreemem - free a virtual memory block, returning it to vmemlist
 *------------------------------------------------------------------------
 */
SYSCALL	vfreemem(block, size)
	struct	mblock	*block;
	unsigned size;
{
	struct	mblock	*p, *q, *top;
	struct	pentry	*pptr;
	
	/* Check for invalid pointers (including SYSERR) */
	if (block == NULL || block == (struct mblock *)SYSERR) {
		return SYSERR;
	}
	
	/* Check if current process has a virtual heap */
	pptr = &proctab[currpid];
	if (pptr->store == -1) {
		kprintf("vfreemem: Process %d has no virtual heap\n", currpid);
		return SYSERR;
	}
	
	/* Round up to word boundary */
	size = (unsigned) roundew(size);
	if (size == 0) {
		return SYSERR;
	}
	
	/* Initialize heap if needed (same as vgetmem) */
	if (pptr->vmemlist == (struct mblock *) 1) {
		unsigned long heap_start = pptr->vhpno * NBPG;
		unsigned long heap_size = pptr->vhpnpages * NBPG;
		pptr->vmemlist = (struct mblock *) heap_start;
		pptr->vmemlist->mnext = NULL;
		pptr->vmemlist->mlen = heap_size;
	}
	
	/* If all memory is allocated (vmemlist is NULL), we can still free */
	if (pptr->vmemlist == NULL) {
		/* Insert as the only free block */
		block->mnext = NULL;
		block->mlen = size;
		pptr->vmemlist = block;
		return OK;
	}
	
	/* Find the right place in the list to insert */
	q = NULL;
	p = pptr->vmemlist;
	while (p != NULL && p < block) {
		q = p;
		p = p->mnext;
	}
	
	/* Insert the block */
	block->mnext = p;
	block->mlen = size;
	if (q == NULL) {
		pptr->vmemlist = block;
	} else {
		q->mnext = block;
	}
	
	/* Coalesce with previous block if adjacent */
	if (q != NULL) {
		top = (struct mblock *)((unsigned)q + q->mlen);
		if (top == block) {
			q->mlen += block->mlen;
			q->mnext = block->mnext;
			block = q;
		}
	}
	
	/* Coalesce with next block if adjacent */
	if (block->mnext != NULL) {
		top = (struct mblock *)((unsigned)block + block->mlen);
		if (top == block->mnext) {
			block->mlen += block->mnext->mlen;
			block->mnext = block->mnext->mnext;
		}
	}
	
	return OK;
}

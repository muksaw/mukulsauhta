/* bsm.c - manage the backing store mapping*/

#include <conf.h>
#include <kernel.h>
#include <paging.h>
#include <proc.h>

/*-------------------------------------------------------------------------
 * init_bsm - initialize bsm_tab
 *-------------------------------------------------------------------------
 */
SYSCALL init_bsm()
{
	int i;
	
	/* Initialize all backing store entries as unmapped */
	for (i = 0; i < 8; i++) {
		bsm_tab[i].bs_status = BSM_UNMAPPED;
		bsm_tab[i].bs_pid = -1;
		bsm_tab[i].bs_vpno = -1;
		bsm_tab[i].bs_npages = 0;
		bsm_tab[i].bs_sem = -1;
	}
	
	return OK;
}

/*-------------------------------------------------------------------------
 * get_bsm - get a free entry from bsm_tab
 * 
 * out variables: avail
 *
 * If a backing store is available, the call returns OK and sets avail
 * to the index of the free backing store.
 * 
 * If no backing stores are available, return SYSERR. You may set avail
 * to any value or not set it at all, since callers should always check
 * the return code prior to making use of out variables.
 *-------------------------------------------------------------------------
 */
SYSCALL get_bsm(int* avail)
{
	int i, j;
	int in_use;
	
	/* Find a backing store not used as a virtual heap by any process */
	for (i = 0; i < 8; i++) {
		in_use = 0;
		
		/* Check if this backing store is used as a virtual heap */
		for (j = 0; j < NPROC; j++) {
			if (proctab[j].pstate != PRFREE && proctab[j].store == i) {
				in_use = 1;
				break;
			}
		}
		
		if (!in_use) {
			*avail = i;
			return OK;
		}
	}
	
	/* No backing store available */
	return SYSERR;
}


/*-------------------------------------------------------------------------
 * free_bsm - free backing store i in the bsm_tab
 *
 * Returns OK if the backing store was successfully freed or if the backing
 * store was already free.
 * 
 * Returns SYSERR if the backing store could not be successfully freed.
 *-------------------------------------------------------------------------
 */
SYSCALL free_bsm(int i)
{
	/* Check if backing store index is valid */
	if (i < 0 || i >= 8) {
		return SYSERR;
	}
	
	/* Mark backing store as unmapped */
	bsm_tab[i].bs_status = BSM_UNMAPPED;
	bsm_tab[i].bs_pid = -1;
	bsm_tab[i].bs_vpno = -1;
	bsm_tab[i].bs_npages = 0;
	bsm_tab[i].bs_sem = -1;
	
	return OK;
}

/*-------------------------------------------------------------------------
 * bsm_lookup - find the backing store and page corresponding to the given
 * pid and vaddr.
 * 
 * out variables: store, pageth
 * 
 * If there is a corresponding backing store and the vaddr is valid,
 * return OK, set store to the backing store index, and pageth to the 
 * relative page number within the backing store.
 * 
 * If no mapping exists or the vaddr is invalid, return SYSERR. You
 * may set store and pageth to any value or not set them at all, since 
 * callers should always check the return code prior to making use of 
 * out variables.
 *-------------------------------------------------------------------------
 */
SYSCALL bsm_lookup(int pid, long vaddr, int* store, int* pageth)
{
	int i;
	unsigned long vpno = (unsigned long)vaddr / NBPG;  /* virtual page number */
	
	/* Search through all backing store mappings */
	for (i = 0; i < 8; i++) {
		if (bsm_tab[i].bs_status == BSM_MAPPED && 
		    bsm_tab[i].bs_pid == pid &&
		    vpno >= bsm_tab[i].bs_vpno &&
		    vpno < bsm_tab[i].bs_vpno + bsm_tab[i].bs_npages) {
			
			*store = bsm_tab[i].bs_sem;  /* bs_sem stores actual backing store ID */
			*pageth = vpno - bsm_tab[i].bs_vpno;
			return OK;
		}
	}
	
	/* No mapping found */
	return SYSERR;
}


/*-------------------------------------------------------------------------
 * bsm_map - add a mapping into bsm_tab for the given pid starting at the
 * vpno.
 *-------------------------------------------------------------------------
 */
SYSCALL bsm_map(int pid, int vpno, int source, int npages)
{
	int i;
	int free_slot = -1;
	
	/* Check if backing store index is valid */
	if (source < 0 || source >= 8) {
		return SYSERR;
	}
	
	/* Check if this specific pid already has a mapping for this vpno range */
	for (i = 0; i < 8; i++) {
		if (bsm_tab[i].bs_status == BSM_MAPPED && 
		    bsm_tab[i].bs_pid == pid) {
			/* Check for overlap with existing mapping */
			int existing_start = bsm_tab[i].bs_vpno;
			int existing_end = bsm_tab[i].bs_vpno + bsm_tab[i].bs_npages;
			int new_start = vpno;
			int new_end = vpno + npages;
			
			if (!(new_end <= existing_start || new_start >= existing_end)) {
				/* Overlap detected */
				return SYSERR;
			}
		}
		
		/* Track first free slot */
		if (free_slot == -1 && bsm_tab[i].bs_status == BSM_UNMAPPED) {
			free_slot = i;
		}
	}
	
	/* No free slot available */
	if (free_slot == -1) {
		return SYSERR;
	}
	
	/* Map the backing store in the free slot */
	bsm_tab[free_slot].bs_status = BSM_MAPPED;
	bsm_tab[free_slot].bs_pid = pid;
	bsm_tab[free_slot].bs_vpno = vpno;
	bsm_tab[free_slot].bs_npages = npages;
	bsm_tab[free_slot].bs_sem = source;  /* Store actual backing store ID in bs_sem */
	
	return OK;
}



/*-------------------------------------------------------------------------
 * bsm_unmap - delete the mapping from bsm_tab that corresponds to the 
 * given pid, vpno pair.
 *-------------------------------------------------------------------------
 */
SYSCALL bsm_unmap(int pid, int vpno)
{
	int i;
	
	/* Find the mapping for this pid and vpno */
	for (i = 0; i < 8; i++) {
		if (bsm_tab[i].bs_status == BSM_MAPPED && 
		    bsm_tab[i].bs_pid == pid &&
		    bsm_tab[i].bs_vpno == vpno) {
			
			/* Unmap the backing store */
			bsm_tab[i].bs_status = BSM_UNMAPPED;
			bsm_tab[i].bs_pid = -1;
			bsm_tab[i].bs_vpno = -1;
			bsm_tab[i].bs_npages = 0;
			bsm_tab[i].bs_sem = -1;
			
			return OK;
		}
	}
	
	/* No mapping found */
	return SYSERR;
}



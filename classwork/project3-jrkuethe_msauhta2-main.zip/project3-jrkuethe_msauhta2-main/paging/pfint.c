/* pfint.c - pfint */

#include <conf.h>
#include <kernel.h>
#include <paging.h>
#include <proc.h>

/* External functions */
extern unsigned long read_cr2(void);
extern void write_cr3(unsigned long);

/* Helper function to invalidate TLB entry */
static void invlpg(unsigned long addr)
{
	asm("invlpg (%0)" : : "r" (addr));
}

/*-------------------------------------------------------------------------
 * pfint - paging fault ISR
 *-------------------------------------------------------------------------
 */
SYSCALL pfint()
{
	unsigned long fault_addr;	/* The faulted address from CR2 */
	unsigned long vp;		/* Virtual page number */
	unsigned long a;		/* Faulted address */
	int p, q;			/* Page directory and page table indices */
	pd_t *pd;			/* Page directory pointer */
	pt_t *pt;			/* Page table pointer */
	int store, pageth;		/* Backing store and page offset */
	int frame_id;			/* Frame ID for new page */
	int pt_frame_id;		/* Frame ID for page table if needed */
	unsigned long page_addr;	/* Physical address of the page */
	
	/* Step 1: Get the faulted address from CR2 register */
	fault_addr = read_cr2();
	a = fault_addr;
	
	/* Step 2: Calculate virtual page number (upper 20 bits) */
	vp = a >> 12;
	
	/* Step 3: Get current process's page directory */
	pd = (pd_t *) proctab[currpid].pdbr;
	
	if (pd == 0) {
		kprintf("pfint: Process %d has no page directory!\n", currpid);
		kill(currpid);
		return SYSERR;
	}
	
	/* Step 4: Check if address is legal (mapped in backing store) */
	if (bsm_lookup(currpid, a, &store, &pageth) == SYSERR) {
		kprintf("pfint: Illegal address 0x%x for process %d\n", a, currpid);
		kill(currpid);
		return SYSERR;
	}
	
	/* Step 5: Parse the virtual address */
	/* p = upper 10 bits (page directory index) */
	/* q = bits [21:12] (page table index) */
	p = (a >> 22) & 0x3FF;
	q = (a >> 12) & 0x3FF;
	
	/* Step 6: Check if page table exists */
	if (pd[p].pd_pres == 0) {
		/* Page table doesn't exist, need to allocate one */
		if (get_frm(&pt_frame_id) == SYSERR) {
			kprintf("pfint: Cannot allocate frame for page table\n");
			kill(currpid);
			return SYSERR;
		}
		
		/* Get physical address of new page table */
		pt = (pt_t *) ((FRAME0 + pt_frame_id) * NBPG);
		
		/* Initialize all entries in the new page table to not present */
		int i;
		for (i = 0; i < 1024; i++) {
			pt[i].pt_pres = 0;
			pt[i].pt_write = 0;
			pt[i].pt_user = 0;
			pt[i].pt_pwt = 0;
			pt[i].pt_pcd = 0;
			pt[i].pt_acc = 0;
			pt[i].pt_dirty = 0;
			pt[i].pt_mbz = 0;
			pt[i].pt_global = 0;
			pt[i].pt_avail = 0;
			pt[i].pt_base = 0;
		}
		
		/* Mark frame as used for page table */
		frm_tab[pt_frame_id].fr_status = FRM_MAPPED;
		frm_tab[pt_frame_id].fr_pid = currpid;
		frm_tab[pt_frame_id].fr_vpno = -1;
		frm_tab[pt_frame_id].fr_refcnt = 0;
		frm_tab[pt_frame_id].fr_type = FR_TBL;
		frm_tab[pt_frame_id].fr_dirty = 0;
		
		/* Set up page directory entry */
		pd[p].pd_pres = 1;
		pd[p].pd_write = 1;
		pd[p].pd_user = 0;
		pd[p].pd_pwt = 0;
		pd[p].pd_pcd = 0;
		pd[p].pd_acc = 0;
		pd[p].pd_mbz = 0;
		pd[p].pd_fmb = 0;
		pd[p].pd_global = 0;
		pd[p].pd_avail = 0;
		pd[p].pd_base = (FRAME0 + pt_frame_id);
	} else {
		/* Page table exists, get pointer to it */
		pt = (pt_t *) (pd[p].pd_base * NBPG);
		pt_frame_id = pd[p].pd_base - FRAME0;
	}
	
	/* Step 7: Increase reference count of page table frame */
	frm_tab[pt_frame_id].fr_refcnt++;
	
	/* Step 8: Check if a frame already exists for this backing store page (for sharing) */
	int found_frame = 0;
	int i;
	for (i = 0; i < NFRAMES; i++) {
		if (frm_tab[i].fr_status == FRM_MAPPED && 
		    frm_tab[i].fr_type == FR_PAGE) {
			/* Check if this frame corresponds to the same backing store page */
			int other_store, other_pageth;
			unsigned long other_vaddr = (unsigned long)frm_tab[i].fr_vpno * NBPG;
			
			if (bsm_lookup(frm_tab[i].fr_pid, other_vaddr, &other_store, &other_pageth) == OK) {
				if (other_store == store && other_pageth == pageth) {
					/* Found a frame for the same backing store page! */
					frame_id = i;
					found_frame = 1;
					break;
				}
			}
		}
	}
	
	if (!found_frame) {
		/* Step 8b: Obtain a free frame for the page */
		if (get_frm(&frame_id) == SYSERR) {
			kprintf("pfint: Cannot allocate frame for page\n");
			kill(currpid);
			return SYSERR;
		}
		/* Step 9: Read page from backing store into the frame */
		page_addr = (FRAME0 + frame_id) * NBPG;
		if (read_bs((char *)page_addr, store, pageth) == SYSERR) {
			kprintf("pfint: Cannot read from backing store\n");
			kill(currpid);
			return SYSERR;
		}
	}
	
	/* Step 10: Update page table entry */
	pt[q].pt_pres = 1;
	pt[q].pt_write = 1;
	pt[q].pt_user = 0;
	pt[q].pt_pwt = 0;
	pt[q].pt_pcd = 0;
	pt[q].pt_acc = 0;
	pt[q].pt_dirty = 0;
	pt[q].pt_mbz = 0;
	pt[q].pt_global = 0;
	pt[q].pt_avail = 0;
	pt[q].pt_base = (FRAME0 + frame_id);
	
	/* Step 11: Update frame table */
	if (!found_frame) {
		/* New frame allocation - set all fields */
		frm_tab[frame_id].fr_status = FRM_MAPPED;
		frm_tab[frame_id].fr_pid = currpid;
		frm_tab[frame_id].fr_vpno = vp;
		frm_tab[frame_id].fr_refcnt = 1;
		frm_tab[frame_id].fr_type = FR_PAGE;
		frm_tab[frame_id].fr_dirty = 0;
	} else {
		/* Reusing existing frame - just increment reference count */
		frm_tab[frame_id].fr_refcnt++;
		frm_tab[frame_id].fr_pid = currpid;
		frm_tab[frame_id].fr_vpno = vp;
	}
	
	/* Step 12: Invalidate TLB entry for this address */
	invlpg(a);
	
	return OK;
}



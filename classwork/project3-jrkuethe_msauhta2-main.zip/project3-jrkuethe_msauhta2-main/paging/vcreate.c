/* vcreate.c - vcreate */
    
#include <conf.h>
#include <i386.h>
#include <kernel.h>
#include <proc.h>
#include <sem.h>
#include <mem.h>
#include <io.h>
#include <paging.h>

/*
static unsigned long esp;
*/

LOCAL	newpid();
/*------------------------------------------------------------------------
 * vcreate - create a process similar to the create syscall, but with a 
 * virtual heap rather than using the shared physical heap.
 *------------------------------------------------------------------------
 */
SYSCALL vcreate(procaddr,ssize,hsize,priority,name,nargs,args)
	int	*procaddr;		/* procedure address		*/
	int	ssize;			/* stack size in words		*/
	int	hsize;			/* virtual heap size in pages	*/
	int	priority;		/* process priority > 0		*/
	char	*name;			/* name (for debugging)		*/
	int	nargs;			/* number of args that follow	*/
	long	args;			/* arguments (treated like an	*/
					/* array in the code)		*/
{
	unsigned long	savsp, *pushsp;
	STATWORD 	ps;    
	int		pid;		/* stores new process id	*/
	struct	pentry	*pptr;		/* pointer to proc. table entry */
	int		i;
	unsigned long	*a;		/* points to list of args	*/
	unsigned long	*saddr;		/* stack address		*/
	int		INITRET();
	int		bs_id;		/* backing store ID */
	int		vpno = 4096;	/* virtual page number for heap start */
	int		pd_frame_id;	/* frame ID for page directory */
	pd_t		*new_pd;	/* pointer to new page directory */
	pd_t		*null_pd;	/* pointer to NULL's page directory */

	disable(ps);
	if (ssize < MINSTK)
		ssize = MINSTK;
	ssize = (int) roundew(ssize);
	
	/* Check if we can get a backing store for the virtual heap */
	if (get_bsm(&bs_id) == SYSERR) {
		kprintf("vcreate: No backing store available\n");
		restore(ps);
		return(SYSERR);
	}
	
	if (((saddr = (unsigned long *)getstk(ssize)) ==
	    (unsigned long *)SYSERR ) ||
	    (pid=newpid()) == SYSERR || priority < 1 ) {
		/* Free the backing store if we can't create the process */
		free_bsm(bs_id);
		restore(ps);
		return(SYSERR);
	}

	numproc++;
	pptr = &proctab[pid];

	pptr->fildes[0] = 0;	/* stdin set to console */
	pptr->fildes[1] = 0;	/* stdout set to console */
	pptr->fildes[2] = 0;	/* stderr set to console */

	for (i=3; i < _NFILE; i++)	/* others set to unused */
		pptr->fildes[i] = FDFREE;

	pptr->pstate = PRSUSP;
	for (i=0 ; i<PNMLEN && (int)(pptr->pname[i]=name[i])!=0 ; i++)
		;
	pptr->pprio = priority;
	pptr->pbase = (long) saddr;
	pptr->pstklen = ssize;
	pptr->psem = 0;
	pptr->phasmsg = FALSE;
	pptr->plimit = pptr->pbase - ssize + sizeof (long);	
	pptr->pirmask[0] = 0;
	pptr->pnxtkin = BADPID;
	pptr->pdevs[0] = pptr->pdevs[1] = pptr->ppagedev = BADDEV;

	/* Set up virtual heap fields */
	pptr->store = bs_id;
	pptr->vhpno = vpno;
	pptr->vhpnpages = hsize;
	
	/* Allocate a page directory for this process */
	if (get_frm(&pd_frame_id) == SYSERR) {
		free_bsm(bs_id);
		freestk(pptr->pbase, pptr->pstklen);
		pptr->pstate = PRFREE;
		numproc--;
		restore(ps);
		return SYSERR;
	}
	
	/* Get physical address of new page directory */
	new_pd = (pd_t *) ((FRAME0 + pd_frame_id) * NBPG);
	null_pd = (pd_t *) proctab[NULLPROC].pdbr;
	
	/* Initialize page directory - copy first 4 entries from NULL to map global 16MB */
	/* First, zero out the entire page directory to avoid garbage */
	bzero(new_pd, NBPG);
	
	/* Copy first 4 entries from NULL process for global 16MB mapping */
	for (i = 0; i < 4; i++) {
		new_pd[i] = null_pd[i];
	}
	
	/* Initialize rest as not present with write permission */
	for (i = 4; i < 1024; i++) {
		new_pd[i].pd_pres = 0;
		new_pd[i].pd_write = 1;
	}
	
	/* Ensure page directory writes are visible before loading into CR3 */
	/* Force a memory barrier by reading back a value */
	{
		volatile unsigned int dummy = *((unsigned int *)&new_pd[0]);
		dummy = dummy;  /* Prevent compiler optimization */
	}
	
	/* Mark frame as used for page directory */
	frm_tab[pd_frame_id].fr_status = FRM_MAPPED;
	frm_tab[pd_frame_id].fr_pid = pid;
	frm_tab[pd_frame_id].fr_vpno = -1;
	frm_tab[pd_frame_id].fr_refcnt = 0;
	frm_tab[pd_frame_id].fr_type = FR_DIR;
	frm_tab[pd_frame_id].fr_dirty = 0;
	
	/* Set process's PDBR to point to new page directory */
	pptr->pdbr = (unsigned long) new_pd;

	/* Map the virtual heap to the backing store */
	if (bsm_map(pid, vpno, bs_id, hsize) == SYSERR) {
		kprintf("vcreate: Failed to map virtual heap\n");
		free_bsm(bs_id);
		proctab[pid].pstate = PRFREE;
		numproc--;
		restore(ps);
		return(SYSERR);
	}
	
	/* Mark vmemlist as uninitialized (special sentinel value) */
	/* It will be initialized on first vgetmem call by the child process */
	pptr->vmemlist = (struct mblock *) 1;

		/* Bottom of stack */
	*saddr = MAGIC;
	savsp = (unsigned long)saddr;

	/* push arguments */
	pptr->pargs = nargs;
	a = (unsigned long *)(&args) + (nargs-1); /* last argument	*/
	for ( ; nargs > 0 ; nargs--)	/* machine dependent; copy args	*/
		*--saddr = *a--;	/* onto created process' stack	*/
	*--saddr = (long)INITRET;	/* push on return address	*/

	*--saddr = pptr->paddr = (long)procaddr; /* where we "ret" to	*/
	*--saddr = savsp;		/* fake frame ptr for procaddr	*/
	savsp = (unsigned long) saddr;

/* this must match what ctxsw expects: flags, regs, old SP */
/* emulate 386 "pushal" instruction */
	*--saddr = 0;
	*--saddr = 0;	/* %eax */
	*--saddr = 0;	/* %ecx */
	*--saddr = 0;	/* %edx */
	*--saddr = 0;	/* %ebx */
	*--saddr = 0;	/* %esp; fill in below */
	pushsp = saddr;
	*--saddr = savsp;	/* %ebp */
	*--saddr = 0;		/* %esi */
	*--saddr = 0;		/* %edi */
	*pushsp = pptr->pesp = (unsigned long)saddr;

	restore(ps);

	return(pid);
}

/*------------------------------------------------------------------------
 * newpid  --  obtain a new (free) process id
 *------------------------------------------------------------------------
 */
LOCAL	newpid()
{
	int	pid;			/* process id to return		*/
	int	i;

	for (i=0 ; i<NPROC ; i++) {	/* check all NPROC slots	*/
		if ( (pid=nextproc--) <= 0)
			nextproc = NPROC-1;
		if (proctab[pid].pstate == PRFREE)
			return(pid);
	}
	return(SYSERR);
}

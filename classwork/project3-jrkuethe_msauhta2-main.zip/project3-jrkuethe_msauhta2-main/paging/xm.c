/* xm.c = xmmap xmunmap */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <paging.h>


/*-------------------------------------------------------------------------
 * xmmap - map the virtual page to the backing store source with a 
 * permitted access range of npages (<= 256) for the calling process.
 * 
 * Return OK if the call succeeded and SYSERR if it failed for any reason.
 *-------------------------------------------------------------------------
 */
SYSCALL xmmap(int virtpage, bsd_t source, int npages)
{
	/* Check parameter validity */
	if (virtpage < 4096) {
		return SYSERR;
	}
	
	if (source < 0 || source >= 8) {
		return SYSERR;
	}
	
	if (npages <= 0 || npages > 256) {
		return SYSERR;
	}
	
	/* Map the backing store to the virtual pages */
	if (bsm_map(currpid, virtpage, source, npages) == SYSERR) {
		return SYSERR;
	}
	
	return OK;
}



/*-------------------------------------------------------------------------
 * xmunmap - free the xmmapping corresponding to virtpage for the calling 
 * process.
 * 
 * This call should not affect any other processes' xmmappings.
 * 
 * Return OK if the unmapping succeeded. Return SYSERR if the unmapping
 * failed or virtpage did not correspond to an existing xmmapping for
 * the calling process.
 *-------------------------------------------------------------------------
 */
SYSCALL xmunmap(int virtpage)
{
	/* Check parameter validity */
	if (virtpage < 4096) {
		return SYSERR;
	}
	
	/* Unmap the backing store mapping */
	if (bsm_unmap(currpid, virtpage) == SYSERR) {
		return SYSERR;
	}
	
	return OK;
}

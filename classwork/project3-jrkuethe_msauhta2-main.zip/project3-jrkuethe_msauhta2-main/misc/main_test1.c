/* user.c - main */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>
#include <paging.h>

/*------------------------------------------------------------------------
 *  main_test1  --  user main program for test 1
 *------------------------------------------------------------------------
 */
#define TPASSED 1
#define TFAILED 0

#define MYBS1	1

#ifndef NBPG
#define NBPG 4096
#endif

void proc_test1(int *ret) {
    char *addr0 = (char *)0x410000; // page 1040
	char *addr1 = (char*)0x40000000; //1G
    int  i= ((unsigned long)addr1)>>12;

    //should not trigger page fault
	*(addr0) = 'D';
	if (xmmap(i, MYBS1, 100) == SYSERR) {
	    *ret = TFAILED;
	    return;
	}

	for (i=0; i<16; i++){
	    *addr1 = 'A'+i;   //trigger page fault for every iteration
	    addr1 += NBPG;	//increment by one page each time
	}

	addr1 = (char*)0x40000000; //1G
	for (i=0; i<16; i++){
		if (*addr1 != 'A'+i){
			*ret = TFAILED;
			return;
		}
		addr1 += NBPG;       //increment by one page each time
	}

	xmunmap(0x40000000>>12);
	return;
}

void test1()
{
	int mypid;
    int ret = TPASSED;

	kprintf("\nTest 1: Testing xmmap.\n");
    mypid = create(proc_test1, 2000, 20, "proc_test1", 1, &ret);
    resume(mypid);
    sleep(4);
    kill(mypid);
    if (ret != TPASSED)
		kprintf("\tFAILED!\n");
	else
		kprintf("\tPASSED!\n");
}
int main() {
    test1();
    shutdown();
}

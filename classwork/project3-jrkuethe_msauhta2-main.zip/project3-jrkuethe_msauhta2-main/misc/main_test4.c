/* user.c - main */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>
#include <paging.h>

/*------------------------------------------------------------------------
 *  main_test5  --  user main program for test 4
 *------------------------------------------------------------------------
 */
#define TPASSED 1
#define TFAILED 0

#define MAXNPG 4096

#ifndef NBPG
#define NBPG 4096
#endif

void proc1_test4(int* ret) {
	int *x;
	int *y;
	int *z;

	x = vgetmem(1024);
	if ((x == NULL) || (x < 0x1000000)) {
		*ret = TFAILED;
    }
	if (x == NULL)
		return;

	*x = 100;
	*(x + 1) = 200;

	if ((*x != 100) || (*(x+1) != 200))
		*ret = TFAILED;
	vfreemem(x, 1024);

	x = vgetmem((MAXNPG + 1) * NBPG); //try to acquire a space that is bigger than size of one backing store
	if (x != SYSERR) {
		*ret = TFAILED;
    }

	x = vgetmem(50*NBPG);
	y = vgetmem(50*NBPG);
	z = vgetmem(50*NBPG);
	if ((x == SYSERR) || (y == SYSERR) || (z != SYSERR)){
		*ret = TFAILED;
		if (x != NULL) vfreemem(x, 50*NBPG);
		if (y != NULL) vfreemem(y, 50*NBPG);
		if (z != NULL) vfreemem(z, 50*NBPG);
		return;
	}
	vfreemem(y, 50*NBPG);
	z = vgetmem(50*NBPG);
	if (z == SYSERR){
		*ret = TFAILED;
	}
	if (x != NULL) vfreemem(x, 50*NBPG);
	if (z != NULL) vfreemem(z, 50*NBPG);
	return;
}

void test4() {
	int pid1;
	int ret = TPASSED;

	kprintf("\nTest 4: vgetmem/vfreemem\n");
	pid1 = vcreate(proc1_test4, 2000, 100, 20, "proc1_test4", 1, &ret);

	resume(pid1);
	sleep(3);
	kill(pid1);
	if (ret != TPASSED)
		kprintf("\tFAILED!\n");
	else
		kprintf("\tPASSED!\n");
}

int main() {
    test4();
    shutdown();
}

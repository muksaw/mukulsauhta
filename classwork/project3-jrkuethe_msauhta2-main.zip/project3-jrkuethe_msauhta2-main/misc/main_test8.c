/* user.c - main */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>
#include <paging.h>

/*------------------------------------------------------------------------
 *  main_test8  --  user main program for test 8
 *------------------------------------------------------------------------
 */
void proc1_test8(char *msg, int lck) {
    int *x;

    kprintf("ready to allocate heap space\n");
    x = vgetmem(1024);
    kprintf("heap allocated at %x\n", x);
    *x = 100;
    *(x + 1) = 200;

    kprintf("heap variable: %d %d\n", *x, *(x + 1));
    vfreemem(x, 1024);
}

void test8() {
    kprintf("\nTest 8: vgetmem/vfreemem README tests");
    int pid1 = vcreate(proc1_test8, 2000, 100, 20, "proc1_test8", 0, NULL);
    kprintf("pid %d has private heap\n", pid1);
    resume(pid1);
    sleep(3);
}

int main() {
    test8();
    shutdown();
}

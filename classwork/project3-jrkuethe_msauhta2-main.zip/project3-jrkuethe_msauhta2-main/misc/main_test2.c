/* user.c - main */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>
#include <paging.h>

/*------------------------------------------------------------------------
 *  main_test2  --  user main program for test 2
 *------------------------------------------------------------------------
 */
#define TPASSED 1
#define TFAILED 0

#define MYVPNO1      0x40000
#define MAX_BSTORE 8

void proc1_test2(int i,int* ret) {
	char *addr;
	int bsize;
	int r;

	if (xmmap(MYVPNO1, i, 100) == SYSERR) {
	    *ret = TFAILED;
	    return 0;
	}
	sleep(4);
	xmunmap(MYVPNO1);
	return;
}
void proc2_test2() {

	/*do nothing*/
	sleep(1);
	return;
}

void test2() {
	int pids[MAX_BSTORE];
	int mypid;
	int i,j;

	int ret = TPASSED;
	kprintf("\nTest 2: Private heap is exclusive\n");


	for(i=0;i < MAX_BSTORE;i++){
		pids[i] = create(proc1_test2, 2000, 20, "proc1_test2", 2, i,&ret);
		if (pids[i] == SYSERR){
			ret = TFAILED;
		}else{
			resume(pids[i]);
		}
	}
	sleep(1);
	mypid = vcreate(proc2_test2, 2000, 100, 20, "proc2_test2", 0, NULL);
	if (mypid != SYSERR)
		ret = TFAILED;

	for(i=0;i < MAX_BSTORE;i++){
		kill(pids[i]);
	}
	if (ret != TPASSED)
		kprintf("\tFAILED!\n");
	else
		kprintf("\tPASSED!\n");
}

int main() {
    test2();
    shutdown();
}

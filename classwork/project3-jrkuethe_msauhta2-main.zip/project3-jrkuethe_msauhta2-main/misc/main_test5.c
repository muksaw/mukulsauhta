/* user.c - main */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>
#include <paging.h>

/*------------------------------------------------------------------------
 *  main_test5  --  user main program for test 5
 *------------------------------------------------------------------------
 */
#define TPASSED 1
#define TFAILED 0

#define MAX_BSTORE 8

#ifndef NBPG
#define NBPG 4096
#endif

void proc1_test5(int *ret) {
    char *vaddr, *addr0, *addr_lastframe, *addr_last;
	int i, j;
	int tempaddr;
    int addrs[1200];

    int maxpage = (NFRAMES - (5 + 1 + 1 + 1));

	int vaddr_beg = 0x40000000;//1GB or page 262144
	int vpno;

	for(i = 0; i < MAX_BSTORE; i++){
		tempaddr = vaddr_beg + 127 * NBPG * i;
		vaddr = (char *) tempaddr;
		vpno = tempaddr >> 12;
		if (xmmap(vpno, i, 127) == SYSERR) {
			*ret = TFAILED;
			kprintf("xmmap call failed\n");
			sleep(3);
			return;
		}

		for (j = 0; j < 127; j++) {
			*(vaddr + j * NBPG) = 'A' + i;
		}

		for (j = 0; j < 127; j++) {
			if (*(vaddr + j * NBPG) != 'A'+i){
				*ret = TFAILED;
				break;
			}
		}
		xmunmap(vpno);
	}
}

void test5(){
	int pid1;
	int ret = TPASSED;
	kprintf("\nTest 5: Stress testing\n");

	pid1 = create(proc1_test5, 2000, 50, "proc1_test5",1,&ret);

	resume(pid1);
	sleep(4);
	kill(pid1);
	if (ret != TPASSED)
		kprintf("\tFAILED!\n");
	else
		kprintf("\tPASSED!\n");
}

int main() {
    test5();
    shutdown();
}

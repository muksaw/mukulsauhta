/* user.c - main */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>
#include <paging.h>

/*------------------------------------------------------------------------
 *  main_test3  --  user main program for test 3
 *------------------------------------------------------------------------
 */
#define TPASSED 1
#define TFAILED 0

#define MYVADDR1	    0x40000000
#define MYVPNO1      0x40000
#define MYVADDR2     0x80000000
#define MYVPNO2      0x80000
#define MYBS1	1

#ifndef NBPG
#define NBPG 4096
#endif

void proc1_test3(int* ret) {
	char *addr;
	int i;

	if (xmmap(MYVPNO1, MYBS1, 100) == SYSERR) {
		kprintf("xmmap call failed\n");
		*ret = TFAILED;
		sleep(3);
		return;
	}

	addr = (char*) MYVADDR1;
	for (i = 0; i < 26; i++) {
		*(addr + i * NBPG) = 'A' + i;
	}

	sleep(6);

	/*Shoud see what proc 2 updated*/
	for (i = 0; i < 26; i++) {
		/*expected output is abcde.....*/
		if (*(addr + i * NBPG) != 'a'+i){
			*ret = TFAILED;
			break;
		}
	}


	xmunmap(MYVPNO1);
	return;
}

void proc2_test3(int *ret) {
	char *addr;
	int i;

	if (xmmap(MYVPNO2, MYBS1, 100) == SYSERR) {
		kprintf("xmmap call failed\n");
		*ret = TFAILED;
		sleep(3);
		return;
	}

	addr = (char*) MYVADDR2;

	/*Shoud see what proc 1 updated*/
	for (i = 0; i < 26; i++) {
		/*expected output is ABCDEF.....*/
		if (*(addr + i * NBPG) != 'A'+i){
			*ret = TFAILED;
			break;
		}
	}

	/*Update the content, proc1 should see it*/
	for (i = 0; i < 26; i++) {
		*(addr + i * NBPG) = 'a' + i;
	}

	xmunmap(MYVPNO2);
	return;
}

void test3() {
	int pid1;
	int pid2;
	int ret = TPASSED;
	kprintf("\nTest 3: Shared backing store\n");

	pid1 = create(proc1_test3, 2000, 20, "proc1_test3", 1, &ret);
	pid2 = create(proc2_test3, 2000, 20, "proc2_test3", 1, &ret);

	resume(pid1);
	sleep(3);
	resume(pid2);

	sleep(10);
	kill(pid1);
	kill(pid2);
	if (ret != TPASSED)
		kprintf("\tFAILED!\n");
	else
		kprintf("\tPASSED!\n");
}

int main() {
    test3();
    shutdown();
}

/* user.c - main */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>
#include <paging.h>

/*------------------------------------------------------------------------
 *  main_test7  --  user main program for test 7
 *------------------------------------------------------------------------
 */
#ifndef NBPG
#define NBPG 4096
#endif

#define TEST1_BS    1
#define PROC1_VPNO  0x40000
#define PROC1_VADDR 0x40000000

void proc1_test7(char *msg, int lck) {
    char *addr;
    int i;

    if (xmmap(PROC1_VPNO, TEST1_BS, 100) == SYSERR) {
        kprintf("xmmap call failed\n");
        sleep(3);
        return;
    }

    addr = (char *) PROC1_VADDR;
    for (i = 0; i < 26; ++i) {
        *(addr + (i * NBPG)) = 'A' + i;
    }

    sleep(6);

    for (i = 0; i < 26; ++i) {
        kprintf("0x%08x: %c\n", addr + (i * NBPG), *(addr + (i * NBPG)));
    }

    xmunmap(PROC1_VPNO);
}

void test7() {
    kprintf("\nTest 7: shared memory README test");
    int pid1 = create(proc1_test7, 2000, 20, "proc1_test7", 0, NULL);
    resume(pid1);
    sleep(10);
}

int main() {
    test7();
    shutdown();
}

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>
#include <paging.h>

/* Use global array instead of local to avoid stack issues */
int global_addrs[1200];

void proc1_test6() {
	int PAGE0 = 0x40000;
	int i,j,temp;
	int cnt = 0;
	int maxpage = (NFRAMES - (5 + 1 + 1 + 1));

	kprintf("Starting, maxpage=%d, NFRAMES=%d\n", maxpage, NFRAMES);
	
	for (i=0;i<=maxpage/150;i++){
		kprintf("Mapping bs %d\n", i);
		if (xmmap(PAGE0+i*150, i, 150) == SYSERR) {
			kprintf("xmmap call failed\n");
			return;
		}
		for(j=0;j < 150;j++) {
			global_addrs[cnt++] = (PAGE0+(i*150) + j) << 12;
		}
	}
	kprintf("Mapped %d addresses successfully\n", cnt);
	kprintf("global_addrs[0]=0x%x, global_addrs[100]=0x%x, global_addrs[500]=0x%x\n", 
	        global_addrs[0], global_addrs[100], global_addrs[500]);

	kprintf("Writing to first 5 addresses to test...\n");
	for(i=0; i < 5; i++) {
		kprintf("  Writing to global_addrs[%d] = 0x%x\n", i, global_addrs[i]);
		*((int *)global_addrs[i]) = i + 1;
		kprintf("    Success!\n");
	}
	
	kprintf("Test completed without crash!\n");
}

void test6(){
	int pid1;
	kprintf("\nTest 6: Minimal test\n");
	enable_pr_debug();
	pid1 = create(proc1_test6, 2000, 20, "proc1_test6", 0, NULL);
	resume(pid1);
	sleep(5);
	kill(pid1);
	kprintf("Finished!\n");
}

int main() {
	test6();
	shutdown();
}

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>
#include <paging.h>

void proc1_test6() {
	int PAGE0 = 0x40000;
	int i,j,temp;
	int addrs[1200];
	int cnt = 0;
	int maxpage = (NFRAMES - (5 + 1 + 1 + 1));

	kprintf("Starting test6 proc, maxpage=%d\n", maxpage);
	
	for (i=0;i<=maxpage/150;i++){
		if (xmmap(PAGE0+i*150, i, 150) == SYSERR) {
			kprintf("xmmap call failed\n");
			return;
		}
		for(j=0;j < 150;j++) {
			addrs[cnt++] = (PAGE0+(i*150) + j) << 12;
		}
	}
	kprintf("Mapped %d addresses\n", cnt);

	kprintf("Phase 1: Filling %d frames...\n", maxpage);
	for(i=0; i < maxpage; i++) {
		*((int *)addrs[i]) = i + 1;
		if (i % 200 == 0) kprintf("  Written to addrs[%d]\n", i);
	}
	kprintf("Phase 1 complete\n");

	kprintf("\n\t 6.1 Expected replaced frame: 8, page: 1032\n\t");
	kprintf("Accessing addrs[%d] = 0x%x\n", maxpage, addrs[maxpage]);
	*((int *)addrs[maxpage]) = maxpage + 1;
	kprintf("Write successful\n");

	kprintf("Phase 2: Resetting access bits...\n");
	for(i=1; i <= maxpage; i++) {
		if ((i != 600) && (i != 800)) { 
			*((int *)addrs[i])= i+1;
		}
	}
	kprintf("Phase 2 complete\n");
	
	kprintf("\n\t 6.2 Expected replaced frame: 608, page: 1632\n\t");
	kprintf("Accessing addrs[%d] = 0x%x\n", maxpage+1, addrs[maxpage+1]);
	*((int *)addrs[maxpage+1]) = maxpage + 2;
	temp = *((int *)addrs[maxpage+1]);
	if (temp != maxpage +2)
		kprintf("\tFAILED!\n");
	else
		kprintf("Read/write OK\n");

	kprintf("\n\t 6.3 Expected replaced frame: 808, page: 1832\n\t");
	kprintf("Accessing addrs[%d] = 0x%x\n", maxpage+2, addrs[maxpage+2]);
	*((int *)addrs[maxpage+2]) = maxpage + 3;
	temp = *((int *)addrs[maxpage+2]);
	if (temp != maxpage +3)
		kprintf("\tFAILED!\n");
	else
		kprintf("Read/write OK\n");

	for (i=0;i<=maxpage/150;i++){
		xmunmap(PAGE0+(i*150));
	}
	kprintf("Unmapped all\n");
}

void test6(){
	int pid1;
	kprintf("\nTest 6: Test SC page replacement policy\n");
	enable_pr_debug();
	kprintf("Debug enabled\n");
	pid1 = create(proc1_test6, 8000, 20, "proc1_test6", 0, NULL);
	resume(pid1);
	sleep(10);
	kill(pid1);
	kprintf("\n\t Finished! Check error and replaced frames\n");
}

int main() {
	test6();
	shutdown();
}

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>
#include <paging.h>

#define TPASSED 1
#define TFAILED 0
#define MAXNPG 4096
#ifndef NBPG
#define NBPG 4096
#endif

void proc1_test4(int* ret) {
	int *x, *y, *z;

	kprintf("Test 4.1: Small allocation\n");
	x = vgetmem(1024);
	kprintf("  vgetmem(1024) returned: 0x%x\n", x);
	if ((x == NULL) || ((unsigned long)x < 0x1000000)) {
		kprintf("  FAILED: x is NULL or < 0x1000000\n");
		*ret = TFAILED;
    }
	if (x == NULL) return;
	
	*x = 100;
	*(x + 1) = 200;
	if ((*x != 100) || (*(x+1) != 200)) {
		kprintf("  FAILED: Cannot read/write\n");
		*ret = TFAILED;
	} else {
		kprintf("  PASSED: Read/write OK\n");
	}
	vfreemem(x, 1024);

	kprintf("Test 4.2: Oversized allocation\n");
	x = vgetmem((MAXNPG + 1) * NBPG);
	kprintf("  vgetmem((4097)*4096) returned: 0x%x\n", x);
	if (x != (int*)SYSERR) {
		kprintf("  FAILED: Should return SYSERR\n");
		*ret = TFAILED;
    } else {
		kprintf("  PASSED: Correctly returned SYSERR\n");
	}

	kprintf("Test 4.3: Multiple 50-page allocations\n");
	x = vgetmem(50*NBPG);
	kprintf("  First 50-page alloc: 0x%x\n", x);
	y = vgetmem(50*NBPG);
	kprintf("  Second 50-page alloc: 0x%x\n", y);
	z = vgetmem(50*NBPG);
	kprintf("  Third 50-page alloc: 0x%x (should be SYSERR)\n", z);
	
	if ((x == (int*)SYSERR) || (y == (int*)SYSERR) || (z != (int*)SYSERR)){
		kprintf("  FAILED: Expected first two to succeed, third to fail\n");
		*ret = TFAILED;
		if (x != NULL && x != (int*)SYSERR) vfreemem(x, 50*NBPG);
		if (y != NULL && y != (int*)SYSERR) vfreemem(y, 50*NBPG);
		if (z != NULL && z != (int*)SYSERR) vfreemem(z, 50*NBPG);
		return;
	}
	kprintf("  PASSED: Allocation behavior correct\n");
	vfreemem(y, 50*NBPG);
	
	z = vgetmem(50*NBPG);
	kprintf("  After freeing y, third alloc: 0x%x\n", z);
	if (z == (int*)SYSERR){
		kprintf("  FAILED: Should succeed after freeing y\n");
		*ret = TFAILED;
	} else {
		kprintf("  PASSED: Correctly reused freed space\n");
	}
	if (x != NULL && x != (int*)SYSERR) vfreemem(x, 50*NBPG);
	if (z != NULL && z != (int*)SYSERR) vfreemem(z, 50*NBPG);
}

void test4() {
	int pid1;
	int ret = TPASSED;

	kprintf("\nTest 4: vgetmem/vfreemem\n");
	pid1 = vcreate(proc1_test4, 2000, 100, 20, "proc1_test4", 1, &ret);

	resume(pid1);
	sleep(3);
	kill(pid1);
	if (ret != TPASSED)
		kprintf("\tFAILED!\n");
	else
		kprintf("\tPASSED!\n");
}

int main() {
    test4();
    shutdown();
}

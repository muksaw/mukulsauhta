#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>
#include <paging.h>

void proc1_test6() {
	int PAGE0 = 0x40000;
	int i,j,temp;
	static int addrs[1200];  // Use static to place on heap instead of stack
	int cnt = 0;
	int maxpage = (NFRAMES - (5 + 1 + 1 + 1));

	for (i=0;i<=maxpage/150;i++){
		if (xmmap(PAGE0+i*150, i, 150) == SYSERR) {
			kprintf("xmmap call failed\n");
			return;
		}
		for(j=0;j < 150;j++) {
			addrs[cnt++] = (PAGE0+(i*150) + j) << 12;
		}
	}

	for(i=0; i < maxpage; i++) {
		*((int *)addrs[i]) = i + 1;
	}

	kprintf("\n\t 6.1 Expected replaced frame: 8, page: 1032\n\t");
	*((int *)addrs[maxpage]) = maxpage + 1;

	for(i=1; i <= maxpage; i++) {
		if ((i != 600) && (i != 800)) {
			*((int *)addrs[i])= i+1;
		}
	}

	kprintf("\n\t 6.2 Expected replaced frame: 608, page: 1632\n\t");
	*((int *)addrs[maxpage+1]) = maxpage + 2;
	temp = *((int *)addrs[maxpage+1]);
	if (temp != maxpage +2)
		kprintf("\tFAILED!\n");

	kprintf("\n\t 6.3 Expected replaced frame: 808, page: 1832\n\t");
	*((int *)addrs[maxpage+2]) = maxpage + 3;
	temp = *((int *)addrs[maxpage+2]);
	if (temp != maxpage +3)
		kprintf("\tFAILED!\n");

	for (i=0;i<=maxpage/150;i++){
		xmunmap(PAGE0+(i*150));
	}
}

void test6(){
	int pid1;
	kprintf("\nTest 6: Test SC page replacement policy (with fix)\n");
	enable_pr_debug();
	pid1 = create(proc1_test6, 8000, 20, "proc1_test6", 0, NULL);  // Increased stack
	resume(pid1);
	sleep(10);
	kill(pid1);
	kprintf("\n\t Finished! Check replaced frames\n");
}

int main() {
	test6();
	shutdown();
}

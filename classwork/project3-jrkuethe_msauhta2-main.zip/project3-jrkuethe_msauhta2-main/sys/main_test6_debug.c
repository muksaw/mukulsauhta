#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>
#include <paging.h>

void proc1_test6() {
	int PAGE0 = 0x40000;
	int i,j,temp;
	int addrs[1200];
	int cnt = 0;
	int maxpage = (NFRAMES - (5 + 1 + 1 + 1));
	
	kprintf("maxpage = %d\n", maxpage);
	kprintf("Will map %d iterations (i=0 to i<=%d)\n", maxpage/150 + 1, maxpage/150);

	for (i=0;i<=maxpage/150;i++){
		kprintf("Attempting xmmap(vpno=0x%x, bs=%d, npages=150)\n", PAGE0+i*150, i);
		if (xmmap(PAGE0+i*150, i, 150) == SYSERR) {
			kprintf("xmmap call FAILED for bs %d\n", i);
			return;
		}
		kprintf("  Success! Storing addresses...\n");
		for(j=0;j < 150;j++) {
			addrs[cnt++] = (PAGE0+(i*150) + j) << 12;
		}
	}
	kprintf("Total addresses stored: %d\n", cnt);

	kprintf("\nPhase 1: Writing to first %d addresses (should fill all frames)\n", maxpage);
	for(i=0; i < maxpage; i++) {
		if (i % 200 == 0) kprintf("  Writing to addrs[%d] = 0x%x\n", i, addrs[i]);
		*((int *)addrs[i]) = i + 1;
	}
	kprintf("Phase 1 complete\n");

	kprintf("\nPhase 2: Triggering first page replacement\n");
	kprintf("  Accessing addrs[%d] = 0x%x\n", maxpage, addrs[maxpage]);
	*((int *)addrs[maxpage]) = maxpage + 1;
	kprintf("  Success!\n");

	kprintf("\nPhase 3: Resetting access bits\n");
	for(i=1; i <= maxpage; i++) {
		if ((i != 600) && (i != 800)) {
			*((int *)addrs[i])= i+1;
		}
	}
	kprintf("Phase 3 complete\n");

	kprintf("\nPhase 4: Second replacement\n");
	kprintf("  Accessing addrs[%d] = 0x%x\n", maxpage+1, addrs[maxpage+1]);
	*((int *)addrs[maxpage+1]) = maxpage + 2;
	temp = *((int *)addrs[maxpage+1]);
	if (temp != maxpage +2)
		kprintf("  FAILED!\n");
	else
		kprintf("  Success!\n");

	kprintf("\nPhase 5: Third replacement\n");
	kprintf("  Accessing addrs[%d] = 0x%x\n", maxpage+2, addrs[maxpage+2]);
	*((int *)addrs[maxpage+2]) = maxpage + 3;
	temp = *((int *)addrs[maxpage+2]);
	if (temp != maxpage +3)
		kprintf("  FAILED!\n");
	else
		kprintf("  Success!\n");

	for (i=0;i<=maxpage/150;i++){
		xmunmap(PAGE0+(i*150));
	}
	kprintf("\nTest 6 completed!\n");
}

void test6(){
	int pid1;
	kprintf("\nTest 6: Test SC page replacement policy\n");
	enable_pr_debug();
	pid1 = create(proc1_test6, 2000, 20, "proc1_test6", 0, NULL);
	resume(pid1);
	sleep(10);
	kill(pid1);
	kprintf("\nFinished!\n");
}

int main() {
	test6();
	shutdown();
}

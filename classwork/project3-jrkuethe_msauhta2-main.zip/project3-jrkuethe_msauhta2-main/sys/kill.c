/* kill.c - kill */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <sem.h>
#include <mem.h>
#include <io.h>
#include <q.h>
#include <stdio.h>
#include <paging.h>

/* External functions for paging cleanup */
extern SYSCALL free_frm(int);
extern SYSCALL free_bsm(int);
extern SYSCALL bsm_unmap(int, int);
extern SYSCALL bsm_lookup(int, long, int*, int*);
extern SYSCALL write_bs(char *, bsd_t, int);

static void cleanup_process_pages(int pid);
static void release_frame_reference(int pid, unsigned long vpno, pt_t *pte);
static void reassign_frame_owner(int frame_id, int old_pid);

/*------------------------------------------------------------------------
 * kill  --  kill a process and remove it from the system
 *------------------------------------------------------------------------
 */
SYSCALL kill(int pid)
{
	STATWORD ps;    
	struct	pentry	*pptr;		/* points to proc. table for pid*/
	int	dev;

	disable(ps);
	if (isbadpid(pid) || (pptr= &proctab[pid])->pstate==PRFREE) {
		restore(ps);
		return(SYSERR);
	}
	if (--numproc == 0)
		xdone();

	dev = pptr->pdevs[0];
	if (! isbaddev(dev) )
		close(dev);
	dev = pptr->pdevs[1];
	if (! isbaddev(dev) )
		close(dev);
	dev = pptr->ppagedev;
	if (! isbaddev(dev) )
		close(dev);

	cleanup_process_pages(pid);

	if (pptr->store != -1) {
		bsm_unmap(pid, pptr->vhpno);
		free_bsm(pptr->store);
		pptr->store = -1;
	}
	
	send(pptr->pnxtkin, pid);

	freestk(pptr->pbase, pptr->pstklen);
	switch (pptr->pstate) {

	case PRCURR:	pptr->pstate = PRFREE;	/* suicide */
			resched();

	case PRWAIT:	semaph[pptr->psem].semcnt++;

	case PRREADY:	dequeue(pid);
			pptr->pstate = PRFREE;
			break;

	case PRSLEEP:
	case PRTRECV:	unsleep(pid);
						/* fall through	*/
	default:	pptr->pstate = PRFREE;
	}
	restore(ps);
	return(OK);
}

/*-----------------------------------------------------------------------
 * cleanup_process_pages -- release all page mappings held by a process
 *-----------------------------------------------------------------------
 */
static void cleanup_process_pages(int pid)
{
	struct pentry *pptr = &proctab[pid];
	pd_t *pd;
	pt_t *pt;
	int p, q;

	if (pptr->pdbr == 0)
		return;

	pd = (pd_t *)pptr->pdbr;

	for (p = 0; p < 1024; p++) {
		if (pd[p].pd_pres == 0)
			continue;

		/* the first four entries reference the global page tables */
		if (p < 4)
			continue;

		pt = (pt_t *)(pd[p].pd_base * NBPG);
		for (q = 0; q < 1024; q++) {
			if (pt[q].pt_pres == 0)
				continue;

			unsigned long vpno = (((unsigned long)p) << 10) | q;
			release_frame_reference(pid, vpno, &pt[q]);
			pt[q].pt_pres = 0;
			pt[q].pt_base = 0;
		}

		{
			int pt_frame = pd[p].pd_base - FRAME0;
			if (pt_frame >= 0 && frm_tab[pt_frame].fr_type == FR_TBL) {
				frm_tab[pt_frame].fr_refcnt = 0;
				free_frm(pt_frame);
			}
		}

		pd[p].pd_pres = 0;
		pd[p].pd_base = 0;
	}

	{
		int pd_frame = (pptr->pdbr / NBPG) - FRAME0;
		if (pd_frame >= 0 && frm_tab[pd_frame].fr_type == FR_DIR) {
			frm_tab[pd_frame].fr_refcnt = 0;
			free_frm(pd_frame);
		}
	}
}

/*-----------------------------------------------------------------------
 * release_frame_reference -- drop this process' reference to a frame
 *-----------------------------------------------------------------------
 */
static void release_frame_reference(int pid, unsigned long vpno, pt_t *pte)
{
	int frame_id;
	unsigned long addr;
	int store, pageth;

	if (pte->pt_base == 0)
		return;

	frame_id = pte->pt_base - FRAME0;
	if (frame_id < 0 || frame_id >= NFRAMES)
		return;

	if (frm_tab[frame_id].fr_type != FR_PAGE)
		return;

	addr = vpno * NBPG;

	if (pte->pt_dirty) {
		if (bsm_lookup(pid, addr, &store, &pageth) == OK) {
			write_bs((char *)((FRAME0 + frame_id) * NBPG), store, pageth);
		}
	}

	if (frm_tab[frame_id].fr_refcnt > 0)
		frm_tab[frame_id].fr_refcnt--;

	if (frm_tab[frame_id].fr_refcnt == 0) {
		free_frm(frame_id);
	} else if (frm_tab[frame_id].fr_pid == pid) {
		reassign_frame_owner(frame_id, pid);
	}
}

/*-----------------------------------------------------------------------
 * reassign_frame_owner -- find another process referencing a shared frame
 *-----------------------------------------------------------------------
 */
static void reassign_frame_owner(int frame_id, int old_pid)
{
	int pid;

	frm_tab[frame_id].fr_pid = -1;
	frm_tab[frame_id].fr_vpno = -1;

	for (pid = 0; pid < NPROC; pid++) {
		struct pentry *pptr = &proctab[pid];
		pd_t *pd;
		pt_t *pt;
		int p, q;

		if (pid == old_pid || pptr->pstate == PRFREE || pptr->pdbr == 0)
			continue;

		pd = (pd_t *)pptr->pdbr;
		for (p = 0; p < 1024; p++) {
			if (pd[p].pd_pres == 0)
				continue;

			pt = (pt_t *)(pd[p].pd_base * NBPG);
			for (q = 0; q < 1024; q++) {
				if (pt[q].pt_pres == 0)
					continue;
				if (pt[q].pt_base - FRAME0 == frame_id) {
					frm_tab[frame_id].fr_pid = pid;
					frm_tab[frame_id].fr_vpno = (((unsigned long)p) << 10) | q;
					return;
				}
			}
		}
	}

	frm_tab[frame_id].fr_pid = -1;
	frm_tab[frame_id].fr_vpno = -1;
}

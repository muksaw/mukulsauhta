/* initialize.c - nulluser, sizmem, sysinit */

#include <conf.h>
#include <i386.h>
#include <kernel.h>
#include <proc.h>
#include <sem.h>
#include <sleep.h>
#include <mem.h>
#include <tty.h>
#include <q.h>
#include <io.h>
#include <paging.h>

/*#define DETAIL */
#define HOLESIZE	(600)	
#define	HOLESTART	(640 * 1024)
#define	HOLEEND		((1024 + HOLESIZE) * 1024)  
/* Extra 600 for bootp loading, and monitor */

extern	int	main();	/* address of user's main prog	*/

extern	int	start();

/* Function prototypes for paging system */
SYSCALL init_bsm();
SYSCALL init_frm();
SYSCALL pfintr();
void enable_paging();
unsigned long read_cr3();
void write_cr3(unsigned long);

LOCAL		sysinit();
LOCAL		init_paging();

/* Declarations of major kernel variables */
struct	pentry	proctab[NPROC]; /* process table			*/
int	nextproc;		/* next process slot to use in create	*/
struct	sentry	semaph[NSEM];	/* semaphore table			*/
int	nextsem;		/* next sempahore slot to use in screate*/
struct	qent	q[NQENT];	/* q table (see queue.c)		*/
int	nextqueue;		/* next slot in q structure to use	*/
char	*maxaddr;		/* max memory address (set by sizmem)	*/
struct	mblock	memlist;	/* list of free memory blocks		*/
#ifdef	Ntty
struct  tty     tty[Ntty];	/* SLU buffers and mode control		*/
#endif

/* active system status */
int	numproc;		/* number of live user processes	*/
int	currpid;		/* id of currently running process	*/
int	reboot = 0;		/* non-zero after first boot		*/

int	rdyhead,rdytail;	/* head/tail of ready list (q indicies)	*/
char 	vers[100];
int	console_dev;		/* the console device			*/

/*  added for the demand paging */
int page_replace_policy = SC;

/* Global data structures for demand paging */
bs_map_t bsm_tab[8];		/* backing store mapping table */
fr_map_t frm_tab[NFRAMES];	/* inverted page table (frame table) */

/************************************************************************/
/***				NOTE:				      ***/
/***								      ***/
/***   This is where the system begins after the C environment has    ***/
/***   been established.  Interrupts are initially DISABLED, and      ***/
/***   must eventually be enabled explicitly.  This routine turns     ***/
/***   itself into the null process after initialization.  Because    ***/
/***   the null process must always remain ready to run, it cannot    ***/
/***   execute code that might cause it to be suspended, wait for a   ***/
/***   semaphore, or put to sleep, or exit.  In particular, it must   ***/
/***   not do I/O unless it uses kprintf for polled output.           ***/
/***								      ***/
/************************************************************************/

/*------------------------------------------------------------------------
 *  nulluser  -- initialize system and become the null process (id==0)
 *------------------------------------------------------------------------
 */
nulluser()				/* babysit CPU when no one is home */
{
        int userpid;

	console_dev = SERIAL0;		/* set console to COM0 */

	initevec();

	kprintf("system running up!\n");
	sysinit();

	enable();		/* enable interrupts */

	sprintf(vers, "PC Xinu %s", VERSION);
	kprintf("\n\n%s\n", vers);
	if (reboot++ < 1)
		kprintf("\n");
	else
		kprintf("   (reboot %d)\n", reboot);


	kprintf("%d bytes real mem\n",
		(unsigned long) maxaddr+1);
#ifdef DETAIL	
	kprintf("    %d", (unsigned long) 0);
	kprintf(" to %d\n", (unsigned long) (maxaddr) );
#endif	

	kprintf("%d bytes Xinu code\n",
		(unsigned long) ((unsigned long) &end - (unsigned long) start));
#ifdef DETAIL	
	kprintf("    %d", (unsigned long) start);
	kprintf(" to %d\n", (unsigned long) &end );
#endif

#ifdef DETAIL	
	kprintf("%d bytes user stack/heap space\n",
		(unsigned long) ((unsigned long) maxaddr - (unsigned long) &end));
	kprintf("    %d", (unsigned long) &end);
	kprintf(" to %d\n", (unsigned long) maxaddr);
#endif	
	
	kprintf("clock %sabled\n", clkruns == 1?"en":"dis");


	/* create a process to execute the user's main program */
	userpid = create(main,INITSTK,INITPRIO,INITNAME,INITARGS);
	resume(userpid);

	while (TRUE)
		/* empty */;
}

/*------------------------------------------------------------------------
 *  sysinit  --  initialize all Xinu data structeres and devices
 *------------------------------------------------------------------------
 */
LOCAL
sysinit()
{
	static	long	currsp;
	int	i,j;
	struct	pentry	*pptr;
	struct	sentry	*sptr;
	struct	mblock	*mptr;
	SYSCALL pfintr();

	

	numproc = 0;			/* initialize system variables */
	nextproc = NPROC-1;
	nextsem = NSEM-1;
	nextqueue = NPROC;		/* q[0..NPROC-1] are processes */

	/* initialize free memory list */
	/* PC version has to pre-allocate 640K-1024K "hole" */
	if (maxaddr+1 > HOLESTART) {
		memlist.mnext = mptr = (struct mblock *) roundmb(&end);
		mptr->mnext = (struct mblock *)HOLEEND;
		mptr->mlen = (int) truncew(((unsigned) HOLESTART -
	     		 (unsigned)&end));
        mptr->mlen -= 4;

		mptr = (struct mblock *) HOLEEND;
		mptr->mnext = 0;
		mptr->mlen = (int) truncew((unsigned)maxaddr - HOLEEND -
	      		NULLSTK);
/*
		mptr->mlen = (int) truncew((unsigned)maxaddr - (4096 - 1024 ) *  4096 - HOLEEND - NULLSTK);
*/
	} else {
		/* initialize free memory list */
		memlist.mnext = mptr = (struct mblock *) roundmb(&end);
		mptr->mnext = 0;
		mptr->mlen = (int) truncew((unsigned)maxaddr - (int)&end -
			NULLSTK);
	}
	

	for (i=0 ; i<NPROC ; i++)	/* initialize process table */
		proctab[i].pstate = PRFREE;


#ifdef	MEMMARK
	_mkinit();			/* initialize memory marking */
#endif

#ifdef	RTCLOCK
	clkinit();			/* initialize r.t.clock	*/
#endif

	mon_init();     /* init monitor */

#ifdef NDEVS
	for (i=0 ; i<NDEVS ; i++ ) {	    
	    init_dev(i);
	}
#endif

	pptr = &proctab[NULLPROC];	/* initialize null process entry */
	pptr->pstate = PRCURR;
	for (j=0; j<7; j++)
		pptr->pname[j] = "prnull"[j];
	pptr->plimit = (WORD)(maxaddr + 1) - NULLSTK;
	pptr->pbase = (WORD) maxaddr - 3;
/*
	pptr->plimit = (WORD)(maxaddr + 1) - NULLSTK - (4096 - 1024 )*4096;
	pptr->pbase = (WORD) maxaddr - 3 - (4096-1024)*4096;
*/
	pptr->pesp = pptr->pbase-4;	/* for stkchk; rewritten before used */
	*( (int *)pptr->pbase ) = MAGIC;
	pptr->paddr = (WORD) nulluser;
	pptr->pargs = 0;
	pptr->pprio = 0;
	currpid = NULLPROC;

	for (i=0 ; i<NSEM ; i++) {	/* initialize semaphores */
		(sptr = &semaph[i])->sstate = SFREE;
		sptr->sqtail = 1 + (sptr->sqhead = newqueue());
	}

	rdytail = 1 + (rdyhead=newqueue());/* initialize ready list */

	/* Initialize demand paging system */
	init_bsm();		/* Initialize backing store mapping table */
	init_frm();		/* Initialize frame table */
	
	/* Set up paging hardware and structures */
	init_paging();		/* Initialize page tables and enable paging */
	
	/* Set up page fault interrupt handler */
	set_evec(14, pfintr);	/* Install page fault ISR */

	return(OK);
}

/*------------------------------------------------------------------------
 * init_paging - initialize page tables and enable paging
 *------------------------------------------------------------------------
 */
LOCAL init_paging()
{
	int i, j;
	pd_t *pd;		/* page directory */
	pt_t *pt;		/* page table */
	int frame_id;
	
	/* Allocate a frame for the NULL process's page directory */
	if (get_frm(&frame_id) == SYSERR) {
		kprintf("init_paging: Cannot allocate page directory frame\n");
		return SYSERR;
	}
	
	/* Get the physical address of the page directory */
	pd = (pd_t *) ((FRAME0 + frame_id) * NBPG);
	
	/* Mark the frame as being used for a page directory */
	frm_tab[frame_id].fr_status = FRM_MAPPED;
	frm_tab[frame_id].fr_pid = NULLPROC;
	frm_tab[frame_id].fr_vpno = -1;  /* Page directory doesn't have a vpno */
	frm_tab[frame_id].fr_refcnt = 0;
	frm_tab[frame_id].fr_type = FR_DIR;
	frm_tab[frame_id].fr_dirty = 0;
	
	/* Initialize all page directory entries to not present */
	for (i = 0; i < 1024; i++) {
		pd[i].pd_pres = 0;
		pd[i].pd_write = 1;
		pd[i].pd_user = 0;
		pd[i].pd_pwt = 0;
		pd[i].pd_pcd = 0;
		pd[i].pd_acc = 0;
		pd[i].pd_mbz = 0;
		pd[i].pd_fmb = 0;
		pd[i].pd_global = 0;
		pd[i].pd_avail = 0;
		pd[i].pd_base = 0;
	}
	
	/* Create 4 global page tables to map the first 16 MB (4096 pages) */
	/* Pages 0-4095 map to physical addresses 0x00000000 - 0x00FFFFFF */
	for (i = 0; i < 4; i++) {
		/* Allocate a frame for this page table */
		if (get_frm(&frame_id) == SYSERR) {
			kprintf("init_paging: Cannot allocate page table frame %d\n", i);
			return SYSERR;
		}
		
		/* Get the physical address of the page table */
		pt = (pt_t *) ((FRAME0 + frame_id) * NBPG);
		
		/* Mark the frame as being used for a page table */
		frm_tab[frame_id].fr_status = FRM_MAPPED;
		frm_tab[frame_id].fr_pid = NULLPROC;
		frm_tab[frame_id].fr_vpno = -1;
		frm_tab[frame_id].fr_refcnt = 1024;  /* All entries will be present */
		frm_tab[frame_id].fr_type = FR_TBL;
		frm_tab[frame_id].fr_dirty = 0;
		
		/* Set up the page directory entry to point to this page table */
		pd[i].pd_pres = 1;
		pd[i].pd_write = 1;
		pd[i].pd_user = 0;
		pd[i].pd_pwt = 0;
		pd[i].pd_pcd = 0;
		pd[i].pd_acc = 0;
		pd[i].pd_mbz = 0;
		pd[i].pd_fmb = 0;
		pd[i].pd_global = 0;
		pd[i].pd_avail = 0;
		pd[i].pd_base = (FRAME0 + frame_id);
		
		/* Initialize all 1024 entries in this page table */
		for (j = 0; j < 1024; j++) {
			int page_num = i * 1024 + j;  /* Physical page number */
			
			pt[j].pt_pres = 1;
			pt[j].pt_write = 1;
			pt[j].pt_user = 0;
			pt[j].pt_pwt = 0;
			pt[j].pt_pcd = 0;
			pt[j].pt_acc = 0;
			pt[j].pt_dirty = 0;
			pt[j].pt_mbz = 0;
			pt[j].pt_global = 0;
			pt[j].pt_avail = 0;
			pt[j].pt_base = page_num;  /* Identity mapping */
		}
	}
	
	/* Store the page directory address in the NULL process's PDBR field */
	proctab[NULLPROC].pdbr = (unsigned long) pd;
	
	/* Set the CR3 register (PDBR) to point to the page directory */
	write_cr3((unsigned long) pd);
	
	/* Enable paging */
	enable_paging();
	
	kprintf("Paging enabled. Page directory at 0x%x\n", (unsigned long) pd);
	
	return OK;
}

stop(s)
char	*s;
{
	kprintf("%s\n", s);
	kprintf("looping... press reset\n");
	while(1)
		/* empty */;
}

delay(n)
int	n;
{
	DELAY(n);
}


#define	NBPG	4096

/*------------------------------------------------------------------------
 * sizmem - return memory size (in pages)
 *------------------------------------------------------------------------
 */
long sizmem()
{
	unsigned char	*ptr, *start, stmp, tmp;
	int		npages;

	/* at least now its hacked to return
	   the right value for the Xinu lab backends (16 MB) */

	return 4096; 

	start = ptr = 0;
	npages = 0;
	stmp = *start;
	while (1) {
		tmp = *ptr;
		*ptr = 0xA5;
		if (*ptr != 0xA5)
			break;
		*ptr = tmp;
		++npages;
		ptr += NBPG;
		if ((int)ptr == HOLESTART) {	/* skip I/O pages */
			npages += (1024-640)/4;
			ptr = (unsigned char *)HOLEEND;
		}
	}
	return npages;
}
